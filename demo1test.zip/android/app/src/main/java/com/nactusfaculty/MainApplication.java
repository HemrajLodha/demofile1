package com.nactusfaculty;

import android.support.annotation.Nullable;

import com.babisoft.ReactNativeLocalization.ReactNativeLocalizationPackage;
import com.dylanvann.fastimage.FastImageViewPackage;
import com.oblador.vectoricons.VectorIconsPackage;
import com.reactnativenavigation.NavigationApplication;
import com.reactnativenavigation.bridge.NavigationReactPackage;
import com.facebook.react.ReactPackage;
import com.facebook.soloader.SoLoader;
import com.github.wuxudong.rncharts.MPAndroidChartPackage;
import com.azendoo.reactnativesnackbar.SnackbarPackage;
import com.facebook.react.bridge.ReadableNativeArray;
import com.facebook.react.bridge.ReadableNativeMap;
import io.github.elyx0.reactnativedocumentpicker.DocumentPickerPackage;
import com.imagepicker.ImagePickerPackage;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

public class MainApplication extends NavigationApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        SoLoader.init(this, /* native exopackage */ false);
        // call for react native >= 0.54.0
        ReadableNativeArray.setUseNativeAccessor(true);
        ReadableNativeMap.setUseNativeAccessor(true);
        try {
            Method arrayUseNativeAccessor = ReadableNativeArray.class.getDeclaredMethod("setUseNativeAccessor", boolean.class);
            if (arrayUseNativeAccessor != null) {
                arrayUseNativeAccessor.invoke(null, true);
            }

            Method mapUseNativeAccessor = ReadableNativeMap.class.getDeclaredMethod("setUseNativeAccessor", boolean.class);
            if (mapUseNativeAccessor != null) {
                mapUseNativeAccessor.invoke(null, true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean isDebug() {
        return BuildConfig.DEBUG;
    }

    protected List<ReactPackage> getPackages() {
        return Arrays.<ReactPackage>asList(
                new NavigationReactPackage(),
                new ReactNativeLocalizationPackage(),
                new FastImageViewPackage(),
                new VectorIconsPackage(),
                new MPAndroidChartPackage(),
                new SnackbarPackage(),
                new DocumentPickerPackage(),
                new ImagePickerPackage()
        );
    }

    @Nullable
    @Override
    public List<ReactPackage> createAdditionalReactPackages() {
        return getPackages();
    }

    @Nullable
    @Override
    public String getJSMainModuleName() {
        return "index";
    }
}
