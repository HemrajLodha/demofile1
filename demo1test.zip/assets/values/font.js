const font = {
    app: "ProximaNova-Regular",
    bold: "ProximaNova-Bold",
    light: "ProximaNova-Light",
    regular: "ProximaNova-Regular",
    semibold: "ProximaNova-Semibold",
    condRegular: "ProximaNovaCond-Regular",
    condSemibold: "ProximaNovaCond-Semibold",
};

export default font;