import React from 'react'
import {Navigation} from "react-native-navigation";
import configureStore from "./store/configureStore";
import {Provider} from "react-redux";
import {registerScreens} from "./screens";
import color from "../assets/values/color";
import font from "../assets/values/font";
import size from "../assets/values/dimens";
import {getUserData, getUserId} from "./store/asyncStoragedata";
import {Alert} from "react-native";
import Strings from "../assets/strings/strings";

const store = configureStore();

registerScreens(store, Provider);

navigateToApp();

export function navigateToApp(logoutMessage) {
    store.dispatch({type: 'RESET'});
    getUserData()
        .then(user => actionToDashboard(user))
        .catch(err => actionToLogin(logoutMessage));
}

export function actionToLogin(logoutMessage) {
    Navigation.startSingleScreenApp(
        {
            screen: {
                screen: 'nactus.Login',
                navigatorStyle: {
                    navBarHidden: true,
                    screenBackgroundColor: color.transparent,
                    rootBackgroundImageName: 'splash'
                }
            },
            passProps: {
                logoutMessage: logoutMessage
            },
            appStyle: {
                navBarButtonColor: color.textColor,
                navBarTextColor: color.textColor,
                navBarTextFontFamily: font.bold,
                navBarTextFontSize: size.text_size_medium,
                navBarBackgroundColor: color.colorPrimary,
                statusBarColor: color.colorPrimaryDark,
                orientation: 'portrait'
            }
        }
    );
};

export function actionToDashboard(user) {
    Navigation.startSingleScreenApp(
        {
            screen: {
                screen: 'nactus.Dashboard',
                navigatorStyle: {
                    navBarCustomView: 'nactus.DashboardBar',
                    screenBackgroundColor: color.transparent,
                    navBarComponentAlignment: 'fill',
                    rootBackgroundImageName: 'splash'
                },
            },
            passProps: {
                user: user
            },
            appStyle: {
                navBarButtonColor: color.textColor,
                navBarTextColor: color.textColor,
                navBarTextFontFamily: font.bold,
                navBarTextFontSize: size.text_size_medium,
                navBarBackgroundColor: color.colorPrimary,
                statusBarColor: color.colorPrimaryDark,
                orientation: 'portrait',
            }
        }
    );
};