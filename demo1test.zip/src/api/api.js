import qs from "qs";
import api from "axios";

import {
    apiLoginRequest,
    apiLoginResponse,
    requestLoginError,
    responseLoginError
} from "./interceptors/loginInterceptor";

import {
    apiNetworkRequest,
    apiNetworkResponse,
    requestNetworkError,
    responseNetworkError
} from "./interceptors/networkInterceptor";

import {
    apiRequest,
    apiResponse,
    requestError,
    responseError
} from "./interceptors/authorizedInterceptor";


/*Live Server*/
let base_url = 'https://www.nactus.com/api/faculties/';
/*Live Server*/

/*/!*Staging Server*!/
let base_url = 'http://staging.nactus.com/api/faculties';
/!*Staging Server*!/*/

let otp_base_url = 'https://api.ringcaptcha.com/';
export const privacy_base_url = 'https://www.nactus.com/privacy.html';
export const terms_base_url = 'https://www.nactus.com/terms.html';
export const disclaimer_base_url = 'https://www.nactus.com/disclamer.html';

export const SMS = "SMS";
export const VOICE = "Voice";
export const COUNTRY_CODE = "+91";
export const APP_KEY = "2uja9e7e1yfefe8e7ymu";
export const API_KEY = "40007b705261f5c5a2990512d0f7b530fdbb38e3";

let apiOauthInstance = api.create();
let apiLoginInstance = api.create();
let apiNetworkInstance = api.create();
let method_type_post = 'POST';

export const authorization = {
    username: 'NThkOTAxNzI1ZWRlZTFh',
    password: '7456f1563edc72e60b5dab4140bb15df8f801563'
};

apiNetworkInstance.interceptors.request.use(apiNetworkRequest, requestNetworkError);
apiNetworkInstance.interceptors.response.use(apiNetworkResponse, responseNetworkError);

apiLoginInstance.interceptors.request.use(apiLoginRequest, requestLoginError);
apiLoginInstance.interceptors.response.use(apiLoginResponse, responseLoginError);

apiOauthInstance.interceptors.request.use(apiRequest, requestError);
apiOauthInstance.interceptors.response.use(apiResponse, responseError);


export function restApiPostLogin(url, data) {
    return apiLoginInstance({
        baseURL: base_url,
        url: url,
        method: method_type_post,
        data: qs.stringify(data),
        auth: authorization,
    });
}

export function restApiPost(url, data) {
    return apiNetworkInstance({
        baseURL: base_url,
        url: url,
        method: method_type_post,
        data: qs.stringify(data),
        auth: authorization,
    });
}

export function restApiPostOTP(url, data) {
    return apiNetworkInstance({
        baseURL: otp_base_url,
        url: url,
        method: method_type_post,
        data: qs.stringify(data),
    });
}

export function restApiPostBearer(url, data, params) {
    return apiOauthInstance({
        baseURL: base_url,
        url: url,
        method: method_type_post,
        params: params,
        data: qs.stringify(data),
    });
}

export function restApiPostBearerMultipart(url, data) {
    return apiOauthInstance({
        baseURL: base_url,
        url: url,
        method: method_type_post,
        data: data,
    });
}

