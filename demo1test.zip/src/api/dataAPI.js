import {restApiPostBearer, restApiPostBearerMultipart} from "./api";

const api_get_profile = '/getProfile';
const api_get_class = '/classlist';
const api_get_subject = '/get_subject_list';
const api_get_student = '/get_students_by_class_id';
const api_get_student_attendance = '/update_attendance';
const api_get_tutor_attendance = '/get_tutor_attendance';
const api_submit_student_marks = '/add_marks';
const api_get_student_marks = '/get_student_marks_graph';
const api_change_password = '/change_password';
const api_get_broadcast = '/broad_cast_list';
const api_send_broadcast = '/multBroadCast';


export function getProfile(data) {
    return restApiPostBearer(api_get_profile, data);
}

export function getClassList(data) {
    return restApiPostBearer(api_get_class, data);
}

export function getSubjectList(data) {
    return restApiPostBearer(api_get_subject, data);
}

export function getStudentList(data) {
    return restApiPostBearer(api_get_student, data);
}

export function getStudentAttendanceList(data) {
    return restApiPostBearer(api_get_student_attendance, data);
}

export function getTutorAttendanceList(data) {
    return restApiPostBearer(api_get_tutor_attendance, data);
}

export function submitStudentMarksData(data) {
    return restApiPostBearer(api_submit_student_marks, data);
}

export function getStudentMarksData(data) {
    return restApiPostBearer(api_get_student_marks, data);
}

export function doChangePassword(data) {
    return restApiPostBearer(api_change_password, data);
}

export function getBroadcastList(data) {
    return restApiPostBearer(api_get_broadcast, data);
}

export function sendBroadcastData(data) {
    return restApiPostBearerMultipart(api_send_broadcast, data);
}