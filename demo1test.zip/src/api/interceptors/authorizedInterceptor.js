import NetworkUtil from "../../utils/NetworkUtil";
import Strings from "../../../assets/strings/strings";
import {getSessionData, getUserSessionData, logout, setTokenData} from "../../store/asyncStoragedata";
import {authorization} from "../api";
import {refreshAccessToken} from "../loginAPI";
import api from "axios";
import {navigateToApp} from "../../App";

export async function apiRequest(config) {
    let networkCnn = await NetworkUtil.checkNetworkConnection();
    if (networkCnn.type === "none") {
        return requestError(Strings.no_internet);
    }
    let token = await getSessionData();
    config.headers.access_token = token.access_token;
    return config;
}

export function requestError(err) {
    console.log('requestError', err);
    return Promise.reject(typeof err === 'string' ? err : Strings.went_wrong);
}

export function apiResponse(response) {
    try {
        console.log('apiResponse', JSON.stringify(response.data));
        return Promise.resolve(response);
    } catch (err) {
        return responseError(err);
    }
}

export function responseError(error) {
    console.log("responseError", error);
    return new Promise((resolve, reject) => {
        const originalRequest = error.config;
        if (error.response && error.response.status === 400 && !originalRequest._retry) {
            originalRequest._retry = true;
            getUserSessionData()
                .then(store => {
                    let userData = JSON.parse(store[0][1]);
                    let tokenData = JSON.parse(store[1][1]);
                    let params = {
                        user_id: userData.id,
                        client_id: authorization.username,
                        client_secret: authorization.password,
                        refresh_token: tokenData.refresh_token,
                    };
                    refreshAccessToken(params)
                        .then((accessRes) => {
                            let tokenData = accessRes.data;
                            setTokenData(tokenData)
                                .then(() => {
                                    originalRequest.headers.access_token = tokenData.access_token;
                                    retryAPIRequest(originalRequest, resolve, reject);
                                })
                                .catch(err => reject(Strings.went_wrong));
                        })
                        .catch(err => {
                            reject(typeof err === 'string' ? err : Strings.session_expired);
                            logoutUser();
                        });
                })
                .catch(err => reject(Strings.went_wrong))
        }
        else if (originalRequest && !error.response) {
            originalRequest._retry = true;
            retryAPIRequest(originalRequest, resolve, reject);
        }
        else {
            reject(typeof error === 'string' ? error : error && error.request && error.request._response || Strings.went_wrong);
        }
    });
}

function retryAPIRequest(originalRequest, resolve, reject) {
    api(originalRequest).then(response => {
        if (response.status === 200) {
            resolve(response);
        } else {
            reject(Strings.went_wrong);
        }
    }).catch(err => reject(typeof err === 'string' ? err : err && err.request && err.request._response || Strings.went_wrong));
}

function logoutUser() {
    logout()
        .then(() => navigateToApp(Strings.session_expired))
        .catch(err => console.log(err));
}