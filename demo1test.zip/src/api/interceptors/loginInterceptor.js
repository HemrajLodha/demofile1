import Strings from "../../../assets/strings/strings";
import NetworkUtil from "../../utils/NetworkUtil";
import {authorization} from "../api";
import {generateAccessToken} from "../loginAPI";
import {setUserSessionData} from "../../store/asyncStoragedata";
import {Alert} from "react-native";

export async function apiLoginRequest(config) {
    let networkCnn = await NetworkUtil.checkNetworkConnection();
    if (networkCnn.type === "none") {
        return requestLoginError(Strings.no_internet);
    }
    return config;
}

export function requestLoginError(err) {
    console.log('requestError', err);
    return Promise.reject(typeof err === 'string' ? err : Strings.went_wrong);
}

export function apiLoginResponse(response) {
    try {
        let data = response.data;

        console.log('apiResponse', JSON.stringify(data));
        if (data && data.status) {
            let userData = data.data;
            let params = {
                user_id: userData.id,
                client_id: authorization.username,
                client_secret: authorization.password,
            };
            return new Promise((resolve, reject) => {
                generateAccessToken(params)
                    .then((accessRes) => {
                        let tokenData = accessRes.data;
                        if (tokenData) {
                            setUserSessionData(userData, tokenData)
                                .then(() => resolve(response))
                                .catch(err => reject(Strings.went_wrong));
                        }
                        else {
                            return reject(Strings.went_wrong);
                        }
                    })
                    .catch(err => {
                        return reject(typeof err === 'string' ? err : Strings.went_wrong);
                    })

            });
        }
        return Promise.resolve(response);
    } catch (err) {
        return responseLoginError(Strings.went_wrong);
    }
}

export function responseLoginError(err) {
    console.log('responseError', err);
    return Promise.reject(typeof err === 'string' ? err : Strings.went_wrong);
}