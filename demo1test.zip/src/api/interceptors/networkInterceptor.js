import NetworkUtil from "../../utils/NetworkUtil";
import Strings from "../../../assets/strings/strings";

export async function apiNetworkRequest(config) {
    let networkCnn = await NetworkUtil.checkNetworkConnection();
    if (networkCnn.type === "none") {
        return requestNetworkError(Strings.no_internet);
    }
    return config;
}

export function requestNetworkError(err) {
    console.log('requestNetworkError', err);
    return Promise.reject(typeof err === 'string' ? err : Strings.went_wrong);
}

export function apiNetworkResponse(response) {
    try {
        console.log('apiResponse', JSON.stringify(response.data));
        return Promise.resolve(response);
    } catch (err) {
        return responseNetworkError(Strings.went_wrong);
    }
}

export function responseNetworkError(error) {
    console.log('ResponseError', error);
    return Promise.reject(typeof error === 'string' ? error : Strings.went_wrong);
}