import {restApiPost, restApiPostBearer, restApiPostLogin, restApiPostOTP} from "./api";


const api_login = '/login';
const api_check_username = '/checkUsername';
const api_update_password = '/updatePassword';
const api_send_otp = '/code/';
const api_verify_otp = '/verify';
const api_token = '/get_token';

export function doLogin(data) {
    return restApiPostLogin(api_login, data);
}

export function doCheckUsername(data) {
    return restApiPost(api_check_username, data);
}

export function doSendOTP(data) {
    return restApiPostOTP(data.app_key + api_send_otp + data.service, data);
}

export function doVerifyOTP(data) {
    return restApiPostOTP(data.app_key + api_verify_otp, data);
}

export function doUpdatePassword(data) {
    return restApiPost(api_update_password, data);
}

export function generateAccessToken(data) {
    return restApiPost(api_token, data);
}

export function refreshAccessToken(data) {
    return restApiPost(api_token, data);
}