export const SortType = {
    TYPE_NAME: 'first_name',
    TYPE_EN: 'enroll_id'
};