import * as types from "./actionTypes";
import {getStudentList, submitStudentMarksData} from "../../api/dataAPI";
import {validateMarks} from "../../utils/ValidateUtils";
import Strings from "../../../assets/strings/strings";


function getData(type) {
    return {
        type: type,
    }
}

function getFetchingDataSuccess(res, subject_id) {
    if (!res.status) {
        return getDataFailure(types.FETCHING_DATA_FAILURE, res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        subject_id: subject_id,
        data: res.data || [],
        url: res.base_url
    }
}

function getSubmitDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(types.SUBMIT_DATA_FAILURE, res.message);
    }
    return {
        type: types.SUBMIT_DATA_SUCCESS,
        message: res.message,
    }
}

function getDataFailure(type, message) {
    return {
        type: type,
        message: message,
    }
}


export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function changeMarks(students, message) {
    return {
        type: types.CHANGE_DATA,
        data: students,
        message: message
    }
}

export function filterData(sort_type) {
    return {
        type: types.FILTER_DATA,
        sort_type: sort_type
    }
}

export function getStudentData(data, subject_id) {
    return (dispatch) => {
        dispatch(getData(types.FETCHING_DATA));
        getStudentList(data)
            .then(res => dispatch(getFetchingDataSuccess(res.data, subject_id)))
            .catch(error => dispatch(getDataFailure(types.FETCHING_DATA_FAILURE, error)));
    }
}

export function submitStudentMarks(data, students) {
    return (dispatch) => {
        let count = 0;
        students = students.map(item => {
            let error = validateMarks(item.marks, data.max_marks);
            if (error)
                count++;
            return error ? {...item, error} : item;
        });
        if (count == 0) {
            dispatch(getData(types.SUBMIT_DATA));
            submitStudentMarksData(data)
                .then(res => dispatch(getSubmitDataSuccess(res.data)))
                .catch(error => dispatch(getDataFailure(types.SUBMIT_DATA_FAILURE, error)));
        }
        else {
            dispatch(changeMarks(students, Strings.error_enter_marks));
        }
    }
}
