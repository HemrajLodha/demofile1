import * as types from "./actionTypes";
import initialState from "./initialState";
import {Utils} from "../../utils/Utils";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isLoading: true,
                isLoaded: false,
                data: [],
                message: null,
                url: null,
            };
        case types.FETCHING_DATA_SUCCESS:
            return {
                ...state,
                isLoading: false,
                isLoaded: !Utils.isEmpty(action.data),
                data: action.data.map(item => {
                    item.enroll_id = (item.enroll_id && !isNaN(Number(item.enroll_id))) ? parseInt(item.enroll_id) : item.enroll_id;
                    item.subject_id = action.subject_id;
                    return item;
                }),
                url: action.url,
                message: null
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isLoading: false,
                isLoaded: false,
                data: [],
                url: null,
                message: action.message,
            };
        case types.CHANGE_DATA:
            return {
                ...state,
                data: action.data,
                isAdding: false,
                isAdded: false,
                isAddedMessage: action.message
            };
        case types.SUBMIT_DATA:
            return {
                ...state,
                isAdding: true,
                isAdded: false,
                isAddedMessage: null
            };
        case types.SUBMIT_DATA_SUCCESS:
            return {
                ...state,
                isAdding: false,
                isAdded: true,
                isAddedMessage: action.message
            };
        case types.SUBMIT_DATA_SUCCESS:
            return {
                ...state,
                isAdding: false,
                isAdded: false,
                isAddedMessage: action.message
            };
        case types.FILTER_DATA: {
            let data = [...state.data];
            data.sort((x, y) => {
                let a = x[action.sort_type];
                let b = y[action.sort_type];
                a = typeof a === 'string' ? a.toLowerCase() : a;
                b = typeof b === 'string' ? b.toLowerCase() : b;
                if (a > b)
                    return 1;
                else if (a < b)
                    return -1;
                else
                    return 0;
            });
            return {
                ...state, data
            };
        }
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}