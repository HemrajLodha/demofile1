export default {
    isLoading: false,
    message: null,
    data: [],
    isLoaded: false,
    url: null,
    isAdding: false,
    isAdded: false,
    isAddedMessage: null
}
