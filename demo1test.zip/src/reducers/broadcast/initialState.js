export default {
    isLoading: false,
    message: null,
    data: [],
}
