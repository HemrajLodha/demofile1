import * as types from "./actionTypes";
import {doCheckUsername, doLogin} from "../../api/loginAPI";


function getData() {
    return {
        type: types.CHECKING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.CHECKING_DATA_SUCCESS,
        message: res.message,
        data: res.data,
    }
}

function getDataFailure(message) {
    return {
        type: types.CHECKING_DATA_FAILURE,
        message: message,
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function doCheckUsernameRequest(data) {
    return (dispatch) => {
        dispatch(getData());
        doCheckUsername(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
