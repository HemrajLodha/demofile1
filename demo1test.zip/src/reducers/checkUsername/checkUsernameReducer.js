import * as types from "./actionTypes";
import initialState from "./initialState";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.CHECKING_DATA:
            return {
                ...state,
                isChecking: true,
                message: null,
                data: null
            };
        case types.CHECKING_DATA_SUCCESS:
            return {
                ...state,
                isChecking: false,
                data: action.data,
                message: action.message,
            };
        case types.CHECKING_DATA_FAILURE:
            return {
                ...state,
                isChecking: false,
                message: action.message,
                data: null
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}