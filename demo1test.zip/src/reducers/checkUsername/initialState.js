export default {
    isChecking: false,
    message: null,
    data: null,
}
