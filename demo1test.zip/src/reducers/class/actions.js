import * as types from "./actionTypes";
import {getClassList} from "../../api/dataAPI";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        data: res.data || []
    }
}

function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}

export function changeCheckAll() {
    return {
        type: types.CHECK_ALL_DATA
    }
}

export function changeCheck(classs, position) {
    return {
        type: types.CHECK_DATA,
        classs: classs,
        position: position
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function getClassData(data) {
    return (dispatch) => {
        dispatch(getData());
        getClassList(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
