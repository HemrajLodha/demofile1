import * as types from "./actionTypes";
import initialState from "./initialState";
import {Utils} from "../../utils/Utils";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isLoading: true,
                isLoaded: false,
                data: [],
                message: null
            };
        case types.FETCHING_DATA_SUCCESS:
            return {
                ...state,
                isLoaded: !Utils.isEmpty(action.data),
                isLoading: false,
                data: action.data,
                message: null
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isLoaded: false,
                isLoading: false,
                data: [],
                message: action.message,
            };
        case types.CHECK_ALL_DATA:
            let checkAll = !state.checkAll;
            return {
                ...state,
                data: state.data.map(item => {
                    if (item.is_message)
                        item.is_selected = checkAll;
                    return {...item};
                }),
                checkAll: checkAll
            };
        case types.CHECK_DATA:
            let classs = action.classs;
            let data = state.data;
            data[action.position] = {...classs};
            let count = 0;
            let dataCount = data.length;
            return {
                ...state,
                data: data.map(item => {
                    if (item.is_selected || !item.is_message)
                        count++;
                    return item;
                }),
                checkAll: count === dataCount
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}