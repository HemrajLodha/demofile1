export default {
    isLoading: false,
    isLoaded: false,
    message: null,
    data: [],
    checkAll: false,
}
