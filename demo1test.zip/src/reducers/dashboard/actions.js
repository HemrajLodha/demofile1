import * as types from "./actionTypes";
import {getProfile} from "../../api/dataAPI";
import {DashboardItemType} from "../../screens/dashboard/item/DashboardItem";
import Strings from "../../../assets/strings/strings";
import {getUserData, setUserData} from "../../store/asyncStoragedata";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(user, error) {
    return {
        type: types.FETCHING_DATA_SUCCESS,
        data: [user, ...data()],
        message: error
    }
}

function getDataFailure(message, user) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}


export function reset() {
    return {
        type: types.RESET_DATA
    }
}

function data() {
    return [
        {
            title: Strings.take_attendance,
            icon: require("../../../assets/images/ic_take_attendance.png"),
            type: DashboardItemType.TYPE_TAKE_ATTENDANCE
        },
        {
            title: Strings.view_attendance,
            icon: require("../../../assets/images/ic_view_attendance.png"),
            type: DashboardItemType.TYPE_VIEW_ATTENDANCE
        },
        {
            title: Strings.add_marks,
            icon: require("../../../assets/images/ic_add_marks.png"),
            type: DashboardItemType.TYPE_ADD_MARKS
        },
        {
            title: Strings.view_marks,
            icon: require("../../../assets/images/ic_view_marks.png"),
            type: DashboardItemType.TYPE_VIEW_MARKS
        },
        {
            title: Strings.broadcast,
            icon: require("../../../assets/images/ic_messages.png"),
            type: DashboardItemType.TYPE_BROADCAST
        },
        {
            title: Strings.settings,
            icon: require("../../../assets/images/ic_settings.png"),
            type: DashboardItemType.TYPE_SETTINGS
        }
    ]
}

export function getDashboardData(data) {
    return (dispatch) => {
        dispatch(getData());
        getUserData()
            .then(user => {
                getProfile(data)
                    .then(res => {
                        res = res.data;
                        if (res.status) {
                            user = res.data;
                            setUserData(user)
                                .then(() => dispatch(getDataSuccess(user)))
                                .catch(err => dispatch(getDataFailure(Strings.went_wrong)));
                            return;
                        }
                        dispatch(getDataSuccess(user));
                    })
                    .catch(error => dispatch(getDataSuccess(user, error)));
            })
            .catch(err => dispatch(getDataFailure(Strings.went_wrong)));
    }
}
