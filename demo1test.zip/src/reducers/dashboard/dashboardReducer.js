import * as types from "./actionTypes";
import initialState from "./initialState";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isLoading: true,
                data: null,
                message: null
            };
        case types.FETCHING_DATA_SUCCESS:
            return {
                ...state,
                isLoading: false,
                data: action.data,
                message: action.message
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isLoading: false,
                data: null,
                message: action.message,
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}