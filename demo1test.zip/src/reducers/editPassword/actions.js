import * as types from "./actionTypes";
import {doChangePassword} from "../../api/dataAPI";
import {doUpdatePassword} from "../../api/loginAPI";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        message: res.message
    }
}

function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function doChangePasswordRequest(data) {
    return (dispatch) => {
        dispatch(getData());
        doChangePassword(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}


export function doUpdatePasswordRequest(data) {
    return (dispatch) => {
        dispatch(getData());
        doUpdatePassword(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}


