import * as types from "./actionTypes";
import initialState from "./initialState";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isUpdating: true,
                isUpdated: false,
                message: null
            };
        case types.FETCHING_DATA_SUCCESS:
            return {
                ...state,
                isUpdating: false,
                isUpdated: true,
                message: action.message,
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isUpdating: false,
                isUpdated: false,
                message: action.message,
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}