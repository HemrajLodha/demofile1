export default {
    isUpdating: false,
    isUpdated: false,
    message: null,
}
