import * as types from "./actionTypes";
import {doLogin} from "../../api/loginAPI";
import {Alert} from "react-native";
import Strings from "../../../assets/strings/strings";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        data: res.data
    }
}

function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function doLoginRequest(data) {
    return (dispatch) => {
        dispatch(getData());
        doLogin(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => {
                dispatch(getDataFailure(error))
            });
    }
}
