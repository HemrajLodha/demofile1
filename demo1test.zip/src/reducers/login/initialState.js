export default {
    isLogin: false,
    message: null,
    data: null,
}
