import {combineReducers} from 'redux'
import loginReducer from "./login/loginReducer";
import dashboardReducer from "./dashboard/dashboardReducer";
import editPasswordReducer from "./editPassword/editPasswordReducer";
import classReducer from "./class/classReducer";
import takeAttendanceReducer from "./takeAttendance/takeAttendanceReducer";
import viewAttendanceReducer from "./viewAttendance/viewAttendanceReducer";
import subjectReducer from "./subject/subjectReducer";
import studentReducer from "./student/studentReducer";
import addMarksReducer from "./addMarks/addMarksReducer";
import viewMarksReducer from "./viewMarks/viewMarksReducer";
import broadcastReducer from "./broadcast/broadcastReducer";
import sendBroadcastReducer from "./sendBroadcast/sendBroadcastReducer";
import checkUsernameReducer from "./checkUsername/checkUsernameReducer";
import sendOTPReducer from "./sendOTP/sendOTPReducer";
import verifyOTPReducer from "./verifyOTP/verifyOTPReducer";

const rootReducer = combineReducers({
    loginReducer,
    checkUsernameReducer,
    sendOTPReducer,
    verifyOTPReducer,
    dashboardReducer,
    editPasswordReducer,
    classReducer,
    subjectReducer,
    studentReducer,
    takeAttendanceReducer,
    viewAttendanceReducer,
    addMarksReducer,
    viewMarksReducer,
    broadcastReducer,
    sendBroadcastReducer,
});

export default rootReducer;

