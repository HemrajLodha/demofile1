import * as types from "./actionTypes";
import {sendBroadcastData} from "../../api/dataAPI";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        message: res.message
    }
}

function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function sendBroadcastRequest(data) {
    return (dispatch) => {
        dispatch(getData());
        sendBroadcastData(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
