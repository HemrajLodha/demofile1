export default {
    isSending: false,
    isSent: false,
    message: null,
}
