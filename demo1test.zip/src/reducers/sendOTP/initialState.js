export default {
    isSending: false,
    retry_in: 0,
    message: null,
    data: null,
}
