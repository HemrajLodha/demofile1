import * as types from "./actionTypes";
import initialState from "./initialState";
import Strings from "../../../assets/strings/strings";
import {Utils} from "../../utils/Utils";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.SENDING_OTP:
            return {
                ...state,
                isSending: true,
                message: null,
            };
        case types.SENDING_OTP_SUCCESS:
            return {
                ...state,
                isSending: false,
                retry_in: action.data && parseInt(action.data.retry_in) || 0,
                data: action.data,
            };
        case types.SENDING_OTP_FAILURE:
            return {
                ...state,
                isSending: false,
                retry_in: action.data && parseInt(action.data.retry_in) || 0,
                message: action.message,
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}


