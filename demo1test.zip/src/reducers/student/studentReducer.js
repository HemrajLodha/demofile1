import * as types from "./actionTypes";
import initialState from "./initialState";
import {Utils} from "../../utils/Utils";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isLoading: true,
                isLoaded: false,
                data: [],
                message: null,
                url: null,
            };
        case types.FETCHING_DATA_SUCCESS:
            return {
                ...state,
                isLoaded: !Utils.isEmpty(action.data),
                isLoading: false,
                data: action.data.map((item, index) => {
                    item.index = index;
                    return item;
                }),
                url: action.url,
                message: null
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isLoaded: false,
                isLoading: false,
                data: [],
                url: null,
                message: action.message,
            };
        case types.CHECK_ALL_DATA:
            let checkAll = !state.checkAll;
            return {
                ...state,
                data: state.data.map(item => {
                    item.is_selected = checkAll;
                    return {...item};
                }),
                checkAll: checkAll
            };
        case types.CHECK_DATA:
            let student = action.student;
            let data = state.data;
            data[action.position] = {...student};
            let count = 0;
            let dataCount = data.length;
            return {
                ...state,
                data: data.map(item => {
                    if (item.is_selected)
                        count++;
                    return item;
                }),
                checkAll: count === dataCount
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}