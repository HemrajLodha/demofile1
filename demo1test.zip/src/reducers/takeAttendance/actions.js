import * as types from "./actionTypes";
import Strings from "../../../assets/strings/strings";
import {DashboardItemType} from "../../screens/dashboard/item/DashboardItem";
import {getStudentAttendanceList, getTutorAttendanceList} from "../../api/dataAPI";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res, user_member_id) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        user_member_id: user_member_id,
        data: res.data || [],
        url: res.base_url,
        message: res.message
    }
}

function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}


export function changeCheckAll() {
    return {
        type: types.CHECK_ALL_DATA
    }
}

export function changeCheck(student) {
    return {
        type: types.CHECK_DATA,
        student: student,
    }
}

export function filterData(sort_type) {
    return {
        type: types.FILTER_DATA,
        sort_type: sort_type
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function getStudentData(data, user_member_id) {
    return (dispatch) => {
        dispatch(getData());
        getStudentAttendanceList(data)
            .then(res => dispatch(getDataSuccess(res.data, user_member_id)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
