export default {
    message: null,
    checkAll: true,
    data: [],
    isLoaded: false,
    url: null
}
