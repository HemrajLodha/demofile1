import * as types from "./actionTypes";
import initialState from "./initialState";
import {Utils} from "../../utils/Utils";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isLoaded: false,
                data: [],
                message: null,
                url: null,
            };
        case types.FETCHING_DATA_SUCCESS: {
            let count = 0;
            let dataCount = action.data.length;
            return {
                ...state,
                isLoaded: !Utils.isEmpty(action.data),
                data: action.data.map((item) => {
                    item.enroll_id = (item.enroll_id && !isNaN(Number(item.enroll_id))) ? parseInt(item.enroll_id) : item.enroll_id;
                    item.user_member_id = action.user_member_id;
                    if (item.is_selected)
                        count++;
                    return item;
                }),
                checkAll: count === dataCount,
                url: action.url,
                message: action.message,
            };
        }
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isLoaded: false,
                data: [],
                url: null,
                message: action.message,
            };
        case types.CHECK_ALL_DATA: {
            let checkAll = !state.checkAll;
            return {
                ...state,
                data: state.data.map(item => {
                    item.is_selected = checkAll;
                    return {...item};
                }),
                checkAll: checkAll,
                message: null,
            };
        }
        case types.CHECK_DATA: {
            let student = action.student;
            let data = state.data;
            let count = 0;
            let dataCount = data.length;
            return {
                ...state,
                data: data.map(item => {
                    if (item.student_id == student.student_id)
                        item = {...student};
                    if (item.is_selected)
                        count++;
                    return item;
                }),
                checkAll: count === dataCount,
                message: null,
            };
        }
        case types.FILTER_DATA: {
            let data = [...state.data];
            data.sort((x, y) => {
                let a = x[action.sort_type];
                let b = y[action.sort_type];
                a = typeof a === 'string' ? a.toLowerCase() : a;
                b = typeof b === 'string' ? b.toLowerCase() : b;
                if (a > b)
                    return 1;
                else if (a < b)
                    return -1;
                else
                    return 0;
            });
            return {
                ...state,
                data,
                message: null,
            };
        }
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}