import * as types from "./actionTypes";
import {doVerifyOTP} from "../../api/loginAPI";
import Strings from "../../../assets/strings/strings";
import {Utils} from "../../utils/Utils";


function getData() {
    return {
        type: types.SENDING_OTP,
    }
}

function getDataSuccess(res) {
    return {
        type: res.status === 'ERROR' ? types.SENDING_OTP_FAILURE : types.SENDING_OTP_SUCCESS,
        data: res,
        message: getMessage(res)
    }
}

function getDataFailure(message) {
    return {
        type: types.SENDING_OTP_FAILURE,
        message: message,
    }
}


function getMessage(data) {
    switch (data.message) {
        case 'ERROR_INVALID_NUMBER':
            return Strings.error_valid_mobile;
        case 'ERROR_WAIT_TO_RETRY':
            return Utils.stringReplace(Strings.error_wait_retry, [data.retry_in]);
        case 'ERROR_INVALID_PIN_CODE':
            return Strings.error_valid_otp;
        default:
            return data.message;
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function doVerifyOTPRequest(data) {
    return (dispatch) => {
        dispatch(getData());
        doVerifyOTP(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
