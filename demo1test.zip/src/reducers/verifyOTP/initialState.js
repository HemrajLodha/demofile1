export default {
    isSending: false,
    message: null,
    data: null,
}
