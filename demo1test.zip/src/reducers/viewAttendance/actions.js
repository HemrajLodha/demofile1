import * as types from "./actionTypes";
import Strings from "../../../assets/strings/strings";
import {DashboardItemType} from "../../screens/dashboard/item/DashboardItem";
import {getStudentAttendanceList, getTutorAttendanceList} from "../../api/dataAPI";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        data: res.data || {},
        message: res.message,
    }
}

function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}


export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function getTutorAttendance(data) {
    return (dispatch) => {
        dispatch(getData());
        getTutorAttendanceList(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
