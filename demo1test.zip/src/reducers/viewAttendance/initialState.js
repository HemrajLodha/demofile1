export default {
    message: null,
    data: null,
    students: [],
    schedules: {}
}
