import * as types from "./actionTypes";
import initialState from "./initialState";
import {Utils} from "../../utils/Utils";
import color from "../../../assets/values/color";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                message: null,
            };
        case types.FETCHING_DATA_SUCCESS:
            let schedules = {};
            action.data.student_schedules.forEach(item => {
                schedules[item.date] = {
                    selected: true,
                    disableTouchEvent: true,
                    selectedColor: item.status == 1 ? color.green : color.error
                }
            });
            return {
                ...state,
                data: action.data.attendance_data,
                students: action.data.students,
                schedules: schedules,
                message: action.message,
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                message: action.message,
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}