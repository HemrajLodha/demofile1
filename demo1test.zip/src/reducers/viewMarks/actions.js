import * as types from "./actionTypes";
import {getStudentMarksData} from "../../api/dataAPI";


function getData() {
    return {
        type: types.FETCHING_DATA,
    }
}

function getDataSuccess(res) {
    if (!res.status) {
        return getDataFailure(res.message);
    }
    return {
        type: types.FETCHING_DATA_SUCCESS,
        data: res.data || [],
        message: res.message,
    }
}

export function getDataFailure(message) {
    return {
        type: types.FETCHING_DATA_FAILURE,
        message: message,
    }
}

export function changePosition(position) {
    return {
        type: types.CHANGE_DATA,
        position: position
    }
}

export function changeGraph(isBarChart) {
    return {
        type: types.CHANGE_GRAPH,
        isBarChart: !isBarChart
    }
}

export function reset() {
    return {
        type: types.RESET_DATA
    }
}

export function getStudentMarks(data) {
    return (dispatch) => {
        dispatch(getData());
        getStudentMarksData(data)
            .then(res => dispatch(getDataSuccess(res.data)))
            .catch(error => dispatch(getDataFailure(error)));
    }
}
