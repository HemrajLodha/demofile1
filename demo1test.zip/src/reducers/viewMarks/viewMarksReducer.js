import * as types from "./actionTypes";
import initialState from "./initialState";
import {Utils} from "../../utils/Utils";

export default (state = initialState, action) => {
    switch (action.type) {
        case types.FETCHING_DATA:
            return {
                ...state,
                isLoading: true,
                isLoaded: false,
                position: 0,
                data: [],
                message: null,
            };
        case types.FETCHING_DATA_SUCCESS:
            let data = action.data.map((item, index) => {
                item.position = index + 1;
                return item;
            });
            return {
                ...state,
                isLoading: false,
                isLoaded: !Utils.isEmpty(data),
                data: [{isBarChart: state.isBarChart, data: data}, ...data],
                message: null,
            };
        case types.FETCHING_DATA_FAILURE:
            return {
                ...state,
                isLoaded: false,
                isLoading: false,
                data: [],
                message: action.message,
            };
        case types.CHANGE_DATA:
            data = state.data.map((item, index) => {
                if (index == 0)
                    return item;
                item.isOpened = item.position === action.position;
                return {...item};
            });
            return {
                ...state,
                data: data
            };
        case types.CHANGE_GRAPH:
            data = state.data;
            let graphData = data[0];
            if (graphData) {
                graphData.isBarChart = action.isBarChart;
                data[0] = {...graphData};
            }
            return {
                ...state,
                isBarChart: action.isBarChart,
                data: data
            };
        case types.RESET_DATA:
            return {
                ...initialState
            };
        default:
            return state;
    }
}