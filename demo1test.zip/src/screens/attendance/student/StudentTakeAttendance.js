import React from "react";
import {StyleSheet, View, Alert} from "react-native";
import ProgressView from "../../../widget/ProgressView";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/takeAttendance/actions";
import {connect} from "react-redux";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import size from "../../../../assets/values/dimens";
import StudentAttendanceItem from "./item/StudentAttendanceItem";
import {ListItem} from "react-native-elements";
import Strings from "../../../../assets/strings/strings";
import color from "../../../../assets/values/color";
import font from "../../../../assets/values/font";
import SearchView from "../../../widget/SearchView";
import DatePickerView from "../../../widget/DatePickerView";
import ErrorView from "../../../widget/ErrorView";
import Moment from "moment/moment";
import Snackbar from "react-native-snackbar";
import {BroadcastType} from "../../broadcast/Broadcast";
import {SortType} from "../../../model/SortType";


class StudentTakeAttendance extends React.Component {


    constructor(props) {
        super(props);

        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.screen_width / 4;
            }
        );

        this.state = {
            classData: undefined,
            student: '',
            attendanceDate: new Date()
        };

        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
    }

    onNavigatorEvent(event) {
        if (event.type == 'NavBarButtonPress') {
            if (event.id == 'submit') {
                this.submitAttendance(this.state, this.props);
            }
        }
    }

    componentDidMount() {
        this.getStudentList(this.state, this.props);
    }

    componentWillUnmount() {
        Snackbar.dismiss();
        this.props.studentActions.reset();
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let {classData} = nextProps;
        let nextState = (prevState.classData == classData) ? null : {
            classData: classData,
        };
        return nextState;
    }

    componentDidUpdate(prevProps, prevState) {
        let {classData, attendanceDate} = this.state;
        let {studentData} = this.props;
        let prevClassData = prevState.classData;
        let prevAttendanceDate = prevState.attendanceDate;
        let prevStudentData = prevProps.studentData;
        Snackbar.dismiss();
        if (prevClassData !== classData || attendanceDate !== prevAttendanceDate) {
            this.getStudentList(this.state, this.props);
        }
        if (studentData !== prevStudentData) {
            this.showSubmitButton(!studentData.isLoaded);
            studentData.message && Snackbar.show({
                title: studentData.message,
                duration: Snackbar.LENGTH_INDEFINITE,
                backgroundColor: color.colorPrimary,
                action: {
                    title: Strings.OK,
                    color: color.white,
                }
            })

        }
    }

    render() {
        let {studentData} = this.props;
        let {attendanceDate, classData, student} = this.state;
        student = new RegExp(student, 'i');
        let students = !studentData.isLoaded ? [] : studentData.data.filter(item => student.test(item.first_name));
        return (
            <React.Fragment>
                <View style={styles.dateSearchContainer}>
                    <SearchView
                        ref={ref => this.searchBar = ref}
                        container={styles.containerSearch}
                        inputContainer={styles.inputContainerSearch}
                        editable={studentData.isLoaded}
                        placeholder={Strings.student_name}
                        onChangeValue={text => this.setState({student: text})}
                    />
                    <DatePickerView
                        ref={ref => this.datePicker = ref}
                        container={styles.containerDate}
                        inputContainer={styles.inputContainerDate}
                        date={attendanceDate}
                        onPick={date => this.setState({attendanceDate: date})}
                    />
                </View>
                <View style={styles.container}>
                    <ListItem containerStyle={styles.listContainer}
                              bottomDivider
                              topDivider
                              rightIcon={!studentData.isLoaded ? undefined : {
                                  name: 'sort',
                                  color: color.white,
                                  underlayColor: color.transparent,
                                  onPress: this.goToFilterStudent.bind(this)
                              }}
                              checkBox={!studentData.isLoaded ? undefined : {
                                  checked: studentData.checkAll,
                                  title: Strings.title_all,
                                  containerStyle: styles.checkboxContainer,
                                  textStyle: styles.checkboxText,
                                  checkedIcon: 'check-square',
                                  checkedColor: color.colorPrimary,
                                  uncheckedColor: color.white,
                                  onPress: this.onPressCheckAll
                              }}
                              title={classData.title}
                              titleStyle={styles.title}
                              subtitle={classData.time_between}
                              subtitleStyle={styles.subtitle}
                    />
                    {
                        !studentData.isLoaded ?
                            <ProgressView/> :
                            <RecyclerListView
                                style={styles.list}
                                layoutProvider={this.layoutProvider}
                                dataProvider={this.dataProvider.cloneWithRows(students)}
                                rowRenderer={this.rowRenderer.bind(this, studentData.url)}/>
                    }
                </View>
            </React.Fragment>

        );
    }

    rowRenderer = (url, type, data, index) => {
        return (
            <StudentAttendanceItem data={data}
                                   url={url}
                                   onChangeCheck={this.onPressAttendance}/>
        )
    };

    getStudentList = ({classData, attendanceDate}, {user}) => {
        let params = {
            class_id: classData.class_id,
            date: Moment(attendanceDate).format('YYYY-MM-DD')
        };
        this.props.studentActions.getStudentData(params, user.id);
    };


    submitAttendance = ({classData, attendanceDate}, {user, studentData}) => {
        let params = {
            class_id: classData.class_id,
            date: Moment(attendanceDate).format('YYYY-MM-DD'),
            tutor_id: user.user_id,
            student_data: JSON.stringify(studentData.data)
        };
        this.props.studentActions.getStudentData(params, user.id);
    };

    onPressCheckAll = () => {
        this.props.studentActions.changeCheckAll();
    };

    onPressAttendance = (student) => {
        this.props.studentActions.changeCheck(student);
    };

    onPressFilter = (sort_type) => {
        this.props.studentActions.filterData(sort_type)
    };

    showSubmitButton = (disabled) => {
        this.props.navigator.setButtons({
            rightButtons: [
                {
                    id: 'submit',
                    title: Strings.submit,
                    disabled: disabled
                }
            ]
        })
    };

    goToFilterStudent = () => {
        this.props.navigator.showLightBox({
            screen: 'nactus.SelectorDialog',
            passProps: {
                title: Strings.sort_students,
                data: [
                    {title: Strings.by_name, type: SortType.TYPE_NAME},
                    {title: Strings.by_enrollment_number, type: SortType.TYPE_EN}
                ],
                onPress: this.onPressFilter.bind(this)
            },
            style: {
                backgroundBlur: 'dark', // 'dark' / 'light' / 'xlight' / 'none' - the type of blur on the background
                backgroundColor: color.light_box_bg, // tint color for the background, you can specify alpha here (optional)
                tapBackgroundToDismiss: true // dismisses LightBox on background taps (optional)
            }
        })
    };


}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: size.size_4
    },
    list: {
        flex: 1,
    },
    listContainer: {
        backgroundColor: color.transparent,
    },
    checkboxContainer: {
        borderWidth: 0,
        backgroundColor: color.transparent,
    },
    checkboxText: {
        color: color.white,
        fontFamily: font.regular,
        fontWeight: '100',
        fontSize: size.text_size_v_small
    },
    title: {
        color: color.white,
        fontFamily: font.bold,
        fontSize: size.text_size_v_medium
    },
    subtitle: {
        color: color.white,
        fontFamily: font.regular,
        fontSize: size.text_size_v_small
    },
    dateSearchContainer: {
        flexDirection: 'row'
    },
    containerSearch: {
        marginTop: size.size_4,
        width: '50%',
    },
    containerDate: {
        marginTop: size.size_4,
        width: '50%',
    },
    inputContainerSearch: {
        marginHorizontal: size.size_4
    },
    inputContainerDate: {
        marginHorizontal: size.size_4
    }
});

function mapStateToProps(state) {
    return {
        studentData: state.takeAttendanceReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        studentActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(StudentTakeAttendance);

