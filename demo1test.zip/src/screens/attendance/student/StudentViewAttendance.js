import React from "react";
import {Alert, StyleSheet, TouchableOpacity, View} from "react-native";
import ProgressView from "../../../widget/ProgressView";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/viewAttendance/actions";
import {connect} from "react-redux";
import size from "../../../../assets/values/dimens";
import {ListItem} from "react-native-elements";
import Strings from "../../../../assets/strings/strings";
import color from "../../../../assets/values/color";
import font from "../../../../assets/values/font";
import SearchView from "../../../widget/SearchView";
import Moment from "moment";
import ErrorView from "../../../widget/ErrorView";
import {Calendar} from "react-native-calendars";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import {Utils} from "../../../utils/Utils";
import Snackbar from "react-native-snackbar";

class StudentViewAttendance extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            classData: undefined,
            attendanceDate: undefined,
            maxDate: undefined,
            student: undefined
        }
    }

    componentWillUnmount() {
        Snackbar.dismiss();
        this.props.studentActions.reset();
    }

    componentDidMount() {
        this.getStudentList(this.state);
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let {classData, attendanceDate = new Date(), maxDate = new Date(), format = 'YYYY-MM-DD'} = nextProps;
        let nextState = (prevState.classData == classData) ? null : {
            classData: classData,
            attendanceDate: Moment(attendanceDate).format(format),
            maxDate: Moment(maxDate).format(format),
            student: undefined
        };
        return nextState;
    }

    componentDidUpdate(prevProps, prevState) {
        let {studentData} = this.props;
        let prevStudentData = prevProps.studentData;
        let {classData, attendanceDate, student} = this.state;
        let prevClassData = prevState.classData;
        let prevAttendanceDate = prevState.attendanceDate;
        let prevStudent = prevState.student;
        Snackbar.dismiss();
        if (classData !== prevClassData || attendanceDate !== prevAttendanceDate || student !== prevStudent) {
            this.getStudentList(this.state);
        }
        if (studentData != prevStudentData) {
            studentData.message && Snackbar.show({
                title: studentData.message,
                duration: Snackbar.LENGTH_INDEFINITE,
                backgroundColor: color.colorPrimary,
                action: {
                    title: Strings.OK,
                    color: color.white,
                }
            });
        }
    }

    render() {
        let {studentData} = this.props;
        let {classData, attendanceDate, maxDate, student} = this.state;
        return (
            <React.Fragment>
                <TouchableOpacity style={styles.dateSearchContainer}
                                  onPress={this.onStudentPress.bind(this, studentData.students)}>
                    <SearchView
                        ref={ref => this.searchBar = ref}
                        pointerEvents="none"
                        container={styles.containerSearch}
                        inputContainer={styles.inputContainerSearch}
                        placeholder={Strings.search_student}
                        value={student ? student.first_name : undefined}
                        editable={false}
                    />
                </TouchableOpacity>
                <View style={styles.container}>
                    <ListItem containerStyle={styles.listContainer}
                              bottomDivider
                              topDivider
                              title={classData.title}
                              titleStyle={styles.title}
                              subtitle={classData.time_between}
                              subtitleStyle={styles.subtitle}
                    />
                    {
                        Utils.isEmpty(studentData.students) ?
                            <ProgressView/> : student &&
                            <KeyboardAwareScrollView bounces={false}>
                                <Calendar
                                    style={styles.calendar}
                                    maxDate={maxDate}
                                    current={attendanceDate}
                                    markedDates={{
                                        [attendanceDate]: {
                                            selected: true,
                                            disableTouchEvent: true,
                                            selectedColor: color.colorPrimary
                                        }, ...studentData.schedules
                                    }}
                                    onMonthChange={this.onMonthChange}
                                />
                                <ListItem containerStyle={styles.listCountContainer}
                                          title={"Total working days in month - " + studentData.data.total_working_days}
                                          titleStyle={styles.titleCount}
                                />
                                <ListItem containerStyle={styles.listCountContainer}
                                          title={"Total present of the month - " + studentData.data.total_presence}
                                          titleStyle={[styles.titleCount, {color: color.green}]}
                                />
                                <ListItem containerStyle={styles.listCountContainer}
                                          title={"Total absent of the month - " + studentData.data.total_absence}
                                          titleStyle={[styles.titleCount, {color: color.error}]}
                                />
                            </KeyboardAwareScrollView>

                    }

                </View>
            </React.Fragment>

        );
    }

    getStudentList = ({classData, attendanceDate, student}) => {
        let params = {
            class_id: classData.class_id,
            date: attendanceDate
        };
        if (student)
            params.student_id = student.student_id;
        this.props.studentActions.getTutorAttendance(params);
    };

    onMonthChange = (month) => {
        this.setState({
            attendanceDate: month.dateString
        });
    };

    onSearchStudent = (student) => {
        this.setState({
            student: student
        });
    };

    onStudentPress = (students) => {
        if (Utils.isEmpty(students)) {
            Alert.alert(Strings.app_name, Strings.no_student_found);
            return
        }
        this.props.navigator.showLightBox({
            screen: 'nactus.SearchStudent',
            passProps: {
                students: students,
                onSearch: this.onSearchStudent
            },
            style: {
                backgroundBlur: 'dark', // 'dark' / 'light' / 'xlight' / 'none' - the type of blur on the background
                backgroundColor: color.light_box_bg, // tint color for the background, you can specify alpha here (optional)
                tapBackgroundToDismiss: true // dismisses LightBox on background taps (optional)
            }
        })
    };
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: size.size_4
    },
    list: {
        flex: 1,
    },
    listContainer: {
        backgroundColor: color.transparent,
    },
    listCountContainer: {
        flex: 1,
        backgroundColor: color.transparent,
        paddingVertical: size.size_0,
        marginTop: size.size_4
    },
    title: {
        color: color.white,
        fontFamily: font.bold,
        fontSize: size.text_size_v_medium
    },
    titleCount: {
        color: color.white,
        fontFamily: font.bold,
        fontSize: size.text_size_small
    },
    subtitle: {
        color: color.white,
        fontFamily: font.regular,
        fontSize: size.text_size_v_small
    },
    dateSearchContainer: {
        flexDirection: 'row'
    },
    containerSearch: {
        marginTop: size.size_4,
    },
    inputContainerSearch: {
        marginHorizontal: size.size_4
    },
    calendar: {
        marginTop: size.size_4
    },

});

function mapStateToProps(state) {
    return {
        studentData: state.viewAttendanceReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        studentActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(StudentViewAttendance);

