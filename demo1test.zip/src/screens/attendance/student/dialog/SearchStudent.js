import React from "react";
import {Card, ListItem} from "react-native-elements";
import {StyleSheet} from "react-native";
import size from "../../../../../assets/values/dimens";
import color from "../../../../../assets/values/color";
import font from "../../../../../assets/values/font";
import IconView from "../../../../widget/IconView";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import Strings from "../../../../../assets/strings/strings";
import SearchView from "../../../../widget/SearchView";


class SearchStudent extends React.Component {

    constructor(props) {
        super(props)
        this.dataProvider = new DataProvider((r1, r2) => {
            return true;//r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.size_48;
            }
        );
        this.state = {
            student: '',
        }
    }

    render() {
        let {students, onSearch} = this.props;
        let {student} = this.state;
        student = new RegExp(student, 'i');
        let searchedStudents = students.filter(item => student.test(item.first_name));
        return (
            <Card containerStyle={styles.container}
                  wrapperStyle={styles.wrapper}
                  title={Strings.search_student}
                  titleStyle={styles.title}>

                <React.Fragment>
                    <SearchView
                        ref={ref => this.searchBar = ref}
                        container={styles.containerSearch}
                        inputContainer={styles.inputContainerSearch}
                        placeholder={Strings.student_name}
                        themeColor={color.gray_700}
                        onChangeValue={text => this.setState({student: text})}
                    />

                    <RecyclerListView
                        style={styles.list}
                        layoutProvider={this.layoutProvider}
                        dataProvider={this.dataProvider.cloneWithRows(searchedStudents)}
                        rowRenderer={this.rowRenderer.bind(this, onSearch)}/>
                </React.Fragment>

                <IconView onPress={this.doClose}/>
            </Card>
        );
    }


    rowRenderer = (onSearch, type, data, index) => {
        return (
            <ListItem containerStyle={styles.listItemContainer}
                      bottomDivider
                      title={data.first_name}
                      titleStyle={styles.titleItem}
                      onPress={() => {
                          this.doClose();
                          onSearch(data)
                      }}
            />
        )
    };

    doClose = () => {
        this.props.navigator.dismissLightBox()
    };

}

const styles = StyleSheet.create({
    container: {
        width: size.screen_width * 0.9,
        height: size.screen_height * 0.8,
        backgroundColor: color.white,
        margin: 0
    },
    wrapper: {
        flex: 1,
        marginBottom: size.size_12,
    },
    title: {
        color: color.colorPrimary,
        fontSize: size.text_size_small,
        fontFamily: font.semibold,
        marginHorizontal: size.size_12,
    },
    containerSearch: {
        marginTop: size.size_4,
        width: '100%',
    },
    inputContainerSearch: {
        marginHorizontal: size.size_4
    },
    list: {
        flex: 1
    },
    listItemContainer: {
        height: size.size_48,
        backgroundColor: color.transparent,
    },
    titleItem: {
        color: color.gray_700,
        fontFamily: font.bold,
        fontSize: size.text_size_small
    },
});

export default SearchStudent;