import React from "react";
import {StyleSheet} from 'react-native';
import {Avatar, ListItem} from "react-native-elements";
import font from "../../../../../assets/values/font";
import size from "../../../../../assets/values/dimens";
import color from "../../../../../assets/values/color";
import Strings from "../../../../../assets/strings/strings";
import FastImage from "react-native-fast-image";
import {Utils} from "../../../../utils/Utils";


class StudentAttendanceItem extends React.Component {
    render() {
        let {url, data, onChangeCheck} = this.props;

        return (
            <ListItem containerStyle={styles.container}
                      contentContainerStyle={styles.contentContainer}
                      checkBox={{
                          checked: data.is_selected,
                          title: data.is_selected ? Strings.title_present : Strings.title_absent,
                          containerStyle: styles.checkboxContainer,
                          textStyle: styles.checkboxText,
                          checkedIcon: 'check-square',
                          checkedColor: color.colorPrimary,
                          uncheckedColor: color.white,
                          onPress: () => {
                              data.is_selected = !data.is_selected;
                              onChangeCheck(data);
                          }
                      }}
                      title={data.first_name}
                      titleStyle={styles.title}
                      subtitle={"E.N. - " + data.enroll_id}
                      subtitleStyle={styles.subtitle}
                      leftAvatar={Utils.isEmpty(data.image) ?
                          <Avatar
                              overlayContainerStyle={{backgroundColor: color.transparent}}
                              containerStyle={styles.image}
                              rounded
                              titleStyle={styles.iconTitle}
                              title={data.first_name.substring(0, 1).toUpperCase()}
                          /> :
                          <FastImage
                              style={styles.image}
                              source={{
                                  uri: Utils.getImageUrl(url, data.student_id, data.image),
                                  priority: FastImage.priority.normal,
                              }}
                              resizeMode={FastImage.resizeMode.cover}/>}
            />
        );
    }
}

const styles = StyleSheet.create({
    container: {
        height: '100%',
        backgroundColor: color.transparent,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5
    },
    contentContainer: {},
    title: {
        color: color.white,
        fontFamily: font.semibold,
        fontSize: size.text_size_small
    },
    subtitle: {
        color: color.white,
        fontFamily: font.regular,
        fontSize: size.text_size_vv_small
    },
    iconTitle: {
        color: color.white,
        fontFamily: font.semibold,
    },
    image: {
        width: size.size_48,
        height: size.size_48,
        borderRadius: size.size_48 / 2,
        backgroundColor: color.light_box_bg,
        borderColor: color.gray_200,
        borderWidth: size.size_1
    },
    checkboxContainer: {
        borderWidth: 0,
        backgroundColor: color.transparent,
    },
    checkboxText: {
        color: color.white,
        fontFamily: font.regular,
        fontWeight: '100',
        fontSize: size.text_size_v_small
    }
});

export default StudentAttendanceItem;