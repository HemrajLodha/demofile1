import React from "react";
import {Alert} from "react-native"
import ProgressView from "../../../widget/ProgressView";
import {MenuProvider} from "react-native-popup-menu";
import PopupMenu from "../../../widget/PopupMenu";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/class/actions";
import {connect} from "react-redux";
import {Utils} from "../../../utils/Utils";
import Strings from "../../../../assets/strings/strings";
import styles from "./styles";
import StudentTakeAttendance from "../student/StudentTakeAttendance";
import ErrorView from "../../../widget/ErrorView";
import Moment from "moment/moment";


class TakeAttendance extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            option: undefined
        };
    }

    componentDidMount() {
        this.getClassList(this.props);
    }

    componentWillUnmount() {
        this.props.classActions.reset();
    }


    render() {
        let {classData, navigator, user} = this.props;
        let {option} = this.state;
        return (
            classData.message ? <ErrorView error={classData.message}/> :
                Utils.isEmpty(classData.data) ?
                    <ProgressView/> :
                    <MenuProvider style={styles.container}>
                        <PopupMenu
                            placeHolder={{title: Strings.select_class, class_id: "-1"}}
                            options={classData.data}
                            selectedKey={'class_id'}
                            selectedTitle={'title'}
                            selected={option ? option.class_id : undefined}
                            onSelect={this.doFilter}/>

                        {
                            option && <React.Fragment>
                                {
                                    option.is_attendance ?
                                        <StudentTakeAttendance
                                            user={user}
                                            classData={option}
                                            navigator={navigator}/> :
                                        <ErrorView
                                            error={Strings.permission_take_attendance}/>
                                }
                            </React.Fragment>
                        }

                    </MenuProvider>
        );
    }

    getClassList = ({user}) => {
        let params = {
            user_member_id: user.id,
            status: 1
        };
        this.props.classActions.getClassData(params);
    };

    doFilter = (option) => {
        this.setState({
            option: option
        })
    }

}

function mapStateToProps(state) {
    return {
        classData: state.classReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        classActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(TakeAttendance);