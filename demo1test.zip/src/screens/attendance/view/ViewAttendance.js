import React from "react";
import {Text, View} from "react-native";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/class/actions";
import {connect} from "react-redux";
import Strings from "../../../../assets/strings/strings";
import {Utils} from "../../../utils/Utils";
import {MenuProvider} from "react-native-popup-menu";
import ProgressView from "../../../widget/ProgressView";
import PopupMenu from "../../../widget/PopupMenu";
import SearchView from "../../../widget/SearchView";
import styles from "./styles";
import StudentViewAttendance from "../student/StudentViewAttendance";
import ErrorView from "../../../widget/ErrorView";


class ViewAttendance extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            option: undefined
        }
    }


    componentDidMount() {
        this.getClassList(this.props);
    }

    componentWillUnmount() {
        this.props.classActions.reset();
    }

    render() {
        let {classData, navigator, user} = this.props;
        let {option} = this.state;
        return (
            classData.message ? <ErrorView error={classData.message}/> :
                Utils.isEmpty(classData.data) ?
                    <ProgressView/> :
                    <MenuProvider style={styles.container}>
                        <PopupMenu
                            placeHolder={{title: Strings.select_class, class_id: "-1"}}
                            options={classData.data}
                            selectedKey={'class_id'}
                            selectedTitle={'title'}
                            selected={option ? option.class_id : undefined}
                            onSelect={this.doFilter}/>

                        {
                            option && <React.Fragment>
                                {
                                    option.is_attendance ?
                                        <StudentViewAttendance
                                            user={user}
                                            classData={option}
                                            navigator={navigator}/> :
                                        <ErrorView
                                            error={Strings.permission_view_attendance}/>
                                }
                            </React.Fragment>
                        }

                    </MenuProvider>
        );
    }

    getClassList = ({user}) => {
        let params = {
            user_member_id: user.id,
            status: 1
        };
        this.props.classActions.getClassData(params);
    };

    doFilter = (option) => {
        this.setState({
            option: option
        })
    }
}

function mapStateToProps(state) {
    return {
        classData: state.classReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        classActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ViewAttendance);