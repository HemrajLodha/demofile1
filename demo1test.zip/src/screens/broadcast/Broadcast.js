import React from "react";
import {View, StyleSheet, Alert} from "react-native";
import * as actions from "../../reducers/broadcast/actions";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import size from "../../../assets/values/dimens";
import ProgressView from "../../widget/ProgressView";
import {Utils} from "../../utils/Utils";
import ErrorView from "../../widget/ErrorView";
import {RecyclerListView, DataProvider, LayoutProvider} from "recyclerlistview";
import BroadcastItem from "./item/BroadcastItem";
import {Icon} from "react-native-elements";
import color from "../../../assets/values/color";
import Strings from "../../../assets/strings/strings";
import BroadcastMessages from "./message/BroadcastMessages";

export const BroadcastType = {
    TYPE_TEXT: 1,
    TYPE_MEDIA: 2
};

class Broadcast extends React.Component {

    constructor(props) {
        super(props);
        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.screen_width * 0.25;
            }
        );
    }

    componentDidMount() {
        this.getBroadcastList(this.props);
    }

    componentWillUnmount() {
        this.props.broadcastActions.reset();
    }

    render() {
        let {broadcastData, user} = this.props;
        return (
            <View style={styles.container}>
                {
                    broadcastData.isLoading ? <ProgressView/> :
                        Utils.isEmpty(broadcastData.data) ? broadcastData.message ?
                            <ErrorView error={broadcastData.message}/> : null
                            :
                            <RecyclerListView
                                style={styles.list}
                                layoutProvider={this.layoutProvider}
                                dataProvider={this.dataProvider.cloneWithRows(broadcastData.data)}
                                rowRenderer={this.rowRenderer}/>
                }
                {
                    !broadcastData.isLoading &&
                    <Icon
                        containerStyle={styles.iconAdd}
                        reverse
                        name={'add'}
                        size={size.size_32}
                        color={color.colorPrimary}
                        onPress={this.goToSendBroadcast.bind(this, user)}/>
                }
            </View>
        );
    }

    rowRenderer = (type, data, index) => {
        return (
            <BroadcastItem
                data={data}
            />
        );
    };

    getBroadcastList = ({user}) => {
        let params = {
            faculty_id: user.id
        };
        this.props.broadcastActions.getBroadcastData(params);
    };

    goToSendBroadcast = (user) => {
        this.props.navigator.showLightBox({
            screen: 'nactus.SelectorDialog',
            passProps: {
                title: Strings.send_broadcast,
                data: [
                    {title: Strings.send_text_broadcast, type: BroadcastType.TYPE_TEXT},
                    {title: Strings.send_media_broadcast, type: BroadcastType.TYPE_MEDIA}
                ],
                onPress: this.goToBroadcastClasses.bind(this, user)
            },
            style: {
                backgroundBlur: 'dark', // 'dark' / 'light' / 'xlight' / 'none' - the type of blur on the background
                backgroundColor: color.light_box_bg, // tint color for the background, you can specify alpha here (optional)
                tapBackgroundToDismiss: true, // dismisses LightBox on background taps (optional)
            }
        })
    };

    goToBroadcastClasses = (user, broadcast_type) => {
        this.props.navigator.push({
            screen: 'nactus.BroadcastClasses',
            backButtonTitle:"Back",
            title: Strings.broadcast,
            passProps: {
                user: user,
                broadcast_type: broadcast_type
            }
        });
    };

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    list: {
        flex: 1,
    },
    iconAdd: {
        position: 'absolute',
        bottom: size.size_16,
        right: size.size_16
    }
});

function mapStateToProps(state) {
    return {
        broadcastData: state.broadcastReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        broadcastActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Broadcast);