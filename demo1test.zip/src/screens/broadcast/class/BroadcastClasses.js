import React from "react";
import {Alert, StyleSheet, Text, View} from "react-native";
import {connect} from "react-redux";
import * as actions from "../../../reducers/class/actions";
import {bindActionCreators} from "redux";
import ProgressView from "../../../widget/ProgressView";
import {Utils} from "../../../utils/Utils";
import ErrorView from "../../../widget/ErrorView";
import size from "../../../../assets/values/dimens";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import {ListItem} from "react-native-elements";
import color from "../../../../assets/values/color";
import font from "../../../../assets/values/font";
import Strings from "../../../../assets/strings/strings";


class BroadcastClasses extends React.Component {

    constructor(props) {
        super(props);
        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.screen_width / 5;
            }
        );
        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
    }

    onNavigatorEvent(event) {
        if (event.type == 'NavBarButtonPress') {
            if (event.id == 'next') {
                this.goToBroadcastStudents(this.props);
            }
        }
    }

    componentDidMount() {
        this.getClassList(this.props);
    }

    componentWillUnmount() {
        this.props.classActions.reset();
    }

    componentDidUpdate(prevProps, prevState) {
        let {classData} = this.props;
        let prevClassData = prevProps.classData;
        if (classData.isLoaded != prevClassData.isLoaded) {
            this.showNextButton(!classData.isLoaded)
        }
    }

    render() {
        let {classData} = this.props;
        return (
            classData.isLoading ? <ProgressView/> :
                Utils.isEmpty(classData.data) ? classData.message ?
                    <ErrorView error={classData.message}/> : null :
                    <React.Fragment>
                        <ListItem containerStyle={[styles.listContainer, {height: -1}]}
                                  checkBox={{
                                      checked: classData.checkAll,
                                      title: Strings.title_select_all,
                                      containerStyle: styles.checkboxContainer,
                                      textStyle: styles.checkboxText,
                                      checkedIcon: 'check-square',
                                      checkedColor: color.colorPrimary,
                                      uncheckedColor: color.white,
                                      onPress: this.onPressCheckAll
                                  }}
                                  title={Strings.select_class}
                                  titleStyle={styles.listTitle}
                        />
                        <RecyclerListView
                            layoutProvider={this.layoutProvider}
                            dataProvider={this.dataProvider.cloneWithRows(classData.data)}
                            rowRenderer={this.rowRenderer}/>
                    </React.Fragment>
        );
    }

    rowRenderer = (type, data, index) => {
        return (
            <ListItem
                containerStyle={styles.listContainer}
                disabled={!data.is_message}
                title={data.title}
                titleStyle={styles.listTitle}
                subtitle={<View>
                    <Text style={styles.listSubtitle}>{data.description}</Text>
                    {
                        !data.is_message &&
                        <Text
                            style={[styles.listSubtitle, {color: color.error}]}>{Strings.permission_send_message}</Text>
                    }
                </View>}
                checkBox={!data.is_message ? undefined : {
                    disabled: !data.is_message,
                    checked: data.is_selected,
                    containerStyle: styles.checkboxContainer,
                    textStyle: styles.checkboxText,
                    checkedIcon: 'check-square',
                    checkedColor: color.colorPrimary,
                    uncheckedColor: color.white,
                    onPress: this.onPressCheck.bind(this, data, index)
                }}
            />
        )
    };

    getClassList = ({user}) => {
        let params = {
            user_member_id: user.id,
            status: 3
        };
        this.props.classActions.getClassData(params);
    };

    onPressCheckAll = () => {
        this.props.classActions.changeCheckAll();
    };

    onPressCheck = (data, position) => {
        data.is_selected = !data.is_selected;
        this.props.classActions.changeCheck(data, position);
    };

    showNextButton = (disabled) => {
        this.props.navigator.setButtons({
            rightButtons: [
                {
                    id: 'next',
                    title: Strings.next,
                    disabled: disabled
                }
            ]
        })
    };

    goToBroadcastStudents = ({user, classData, broadcast_type}) => {
        let classIds = classData.data
            .filter(item => item.is_selected)
            .map(item => item.class_id)
            .join(',');
        if (!Utils.isNull(classIds)) {
            this.props.navigator.push({
                screen: 'nactus.BroadcastStudents',
                title: Strings.broadcast,
                backButtonTitle:"Back",
                passProps: {
                    user: user,
                    classIds: classIds,
                    broadcast_type: broadcast_type
                }
            });
        }
        else {
            Alert.alert(Strings.app_name, Strings.error_classOption,
                [
                    {text: Strings.OK}
                ],
                {cancelable: false});
        }
    };
}

const styles = StyleSheet.create({
    listContainer: {
        height: "100%",
        backgroundColor: color.transparent,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5
    },
    listTitle: {
        color: color.white,
        fontSize: size.text_size_small,
        fontFamily: font.semibold
    },
    listSubtitle: {
        color: color.white,
        fontSize: size.text_size_vv_small,
        fontFamily: font.regular
    },
    checkboxContainer: {
        borderWidth: 0,
        backgroundColor: color.transparent,
    },
    checkboxText: {
        color: color.white,
        fontFamily: font.regular,
        fontWeight: '100',
        fontSize: size.text_size_v_small
    }
});

function mapStateToProps(state) {
    return {
        classData: state.classReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        classActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(BroadcastClasses);

