import React from 'react';
import {Icon, ListItem} from "react-native-elements";
import {Text, StyleSheet, View} from "react-native";
import Moment from "moment";
import color from "../../../../assets/values/color";
import size from "../../../../assets/values/dimens";
import font from "../../../../assets/values/font";


class BroadcastItem extends React.Component {

    render() {
        let {data} = this.props;
        let metadata = JSON.parse(data.metadata);
        let isText = metadata.messageType == 1;
        console.log("Time", data.created);
        return (
            isText ? this.getTextMassage(data, metadata) : this.getMultimediaMassage(data, metadata)
        );
    }


    getTextMassage = (data, metadata) => {
        return (
            <ListItem
                containerStyle={styles.container}
                bottomDivider
                title={data.student_name}
                titleStyle={styles.title}
                subtitle={metadata.message}
                subtitleStyle={styles.subtitle}
                subtitleProps={{numberOfLines: 2}}
                rightElement={<View style={styles.dateContainer}>
                    <Text style={styles.date}>
                        {Moment(data.created, 'YYYY-MM-DD HH:mm:ss').format('MMM DD, YYYY, hh:mm A')}
                    </Text>
                </View>}/>
        )
    };

    getMultimediaMassage = (data, metadata) => {
        let message = metadata.message.split(':;];:');
        let url = message[0].split(' ')[0];
        let caption = message[1];
        let fileName = url.substring(url.lastIndexOf('/') + 1);
        return (
            <ListItem
                containerStyle={styles.container}
                title={data.student_name}
                titleStyle={styles.title}
                subtitle={<View style={styles.subtitleContainer}>
                    <Icon name={'file'}
                          size={size.text_size_v_small}
                          color={color.white}
                          type={'font-awesome'}/>
                    <Text style={[styles.subtitle, {marginLeft: size.size_8}]}>
                        {caption}
                    </Text>
                </View>}
                rightElement={<View style={styles.dateContainer}>
                    <Text style={styles.date}>
                        {Moment(data.created, 'YYYY-MM-DD HH:mm:ss').format('MMM DD, YYYY, hh:mm A')}
                    </Text>
                </View>}/>
        )
    };

}

const styles = StyleSheet.create({
    container: {
        height: '100%',
        backgroundColor: color.transparent,
        paddingVertical: size.size_24,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5
    },
    title: {
        color: color.white,
        fontSize: size.text_size_small,
        fontFamily: font.semibold
    },
    subtitleContainer: {
        flexDirection: 'row',
        alignItems: 'center'
    },
    subtitle: {
        color: color.white,
        fontSize: size.text_size_v_small,
        fontFamily: font.regular,
    },
    dateContainer: {
        position: 'absolute',
        bottom: size.size_8,
        right: size.size_8,
    },
    date: {
        color: color.white,
        fontSize: size.text_size_v_small,
        fontFamily: font.semibold,
    }
});

export default BroadcastItem;