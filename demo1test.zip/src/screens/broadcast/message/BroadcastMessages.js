import React from "react";
import {Alert, StyleSheet, Text, TouchableOpacity, View} from "react-native";
import {BroadcastType} from "../Broadcast";
import InputView from "../../../widget/InputView";
import ButtonView from "../../../widget/ButtonView";
import Strings from "../../../../assets/strings/strings";
import size, {isIOS} from "../../../../assets/values/dimens";
import color from "../../../../assets/values/color";
import font from "../../../../assets/values/font";
import * as actions from "../../../reducers/sendBroadcast/actions";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {validate} from "../../../utils/ValidateUtils";
import ImagePicker from "react-native-image-picker";
import DocumentPicker from 'react-native-document-picker';
import {Utils} from "../../../utils/Utils";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import {Icon, ListItem} from "react-native-elements";


class BroadcastMessages extends React.Component {

    constructor(props) {
        super(props);
        this.length = 1000;
        this.state = {
            message: undefined,
            messageLength: 0,
            messageError: undefined,
            files: [],
            fileError: undefined
        };

        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.size_48;
            }
        );
    }

    componentWillUnmount() {
        this.props.broadcastActions.reset();
    }

    componentDidUpdate(prevProps, prevState) {
        let {broadcastData, navigator} = this.props;
        let prevBroadcastData = prevProps.broadcastData;


        if (broadcastData.message !== prevBroadcastData.message) {
            broadcastData.message && Alert.alert(Strings.app_name, broadcastData.message,
                [
                    {
                        text: 'OK', onPress: broadcastData.isSent ? () => navigator.popToRoot() : undefined
                    },
                ],
                {cancelable: false});
        }
    }

    render() {
        let {broadcastData, broadcast_type} = this.props;
        let {message, messageLength, messageError, files, fileError} = this.state;
        let isText = broadcast_type === BroadcastType.TYPE_TEXT;
        return (
            <View style={styles.container}>
                <InputView
                    isLabel={false}
                    multiline={isText}
                    maxLength={this.length}
                    underline={false}
                    editable={!broadcastData.isSending}
                    placeholder={isText ? Strings.type_message : Strings.type_caption}
                    value={message}
                    errorMessage={messageError}
                    onChangeValue={text => {
                        this.setState({
                            message: text,
                            messageLength: text.length
                        })
                    }}
                />

                {
                    isText ? <Text style={styles.counter}>
                            {messageLength}/{this.length}
                        </Text> :
                        <TouchableOpacity disabled={broadcastData.isSending}
                                          onPress={this.openPickerSelector.bind(this, files)}>
                            <InputView
                                pointerEvents="none"
                                isLabel={false}
                                underline={false}
                                editable={false}
                                placeholder={Strings.attach_files}
                                iconName={'paperclip'}
                                iconType={'font-awesome'}
                                errorMessage={fileError}

                            />
                        </TouchableOpacity>
                }
                {
                    !Utils.isEmpty(files) && <RecyclerListView
                        style={styles.list}
                        layoutProvider={this.layoutProvider}
                        dataProvider={this.dataProvider.cloneWithRows(files)}
                        rowRenderer={this.rowRenderer.bind(this, files)}/>
                }


                <ButtonView
                    style={!Utils.isEmpty(files) ? {marginTop: 0} : undefined}
                    title={Strings.send_broadcast}
                    loading={broadcastData.isSending}
                    onPress={() => this.sendBroadcast(isText, this.state, this.props)}/>
            </View>
        );
    }

    rowRenderer = (files, type, data, index) => {
        return (
            <ListItem
                containerStyle={styles.fileContainer}
                title={data.name}
                titleStyle={styles.fileTitle}
                leftIcon={{
                    name: 'file',
                    type: 'font-awesome',
                    color: color.white,
                    size: size.text_size_v_medium,
                }}
                rightElement={<Icon
                    name={'delete'}
                    color={color.white}
                    size={size.text_size_v_medium}
                    underlayColor={color.transparent}
                    onPress={() => {
                        this.setState({files: files.filter(item => item !== data)})
                    }
                    }/>
                }
            />
        );
    };

    sendBroadcast = (isText, {message, files}, {user, studentIds}) => {
        let messageError = isText ? validate('message', message) : validate('caption', message);
        let fileError = isText ? undefined : validate('file', Utils.isEmpty(files) ? undefined : files);
        this.setState({
            messageError: messageError,
            fileError: fileError
        }, () => {
            if (!messageError && !fileError) {
                let formData = new FormData();
                formData.append("user_id", user.user_id);
                formData.append("user_member_id", user.id);
                formData.append("student_ids", studentIds);
                formData.append("message", message);
                if (!Utils.isEmpty(files)) {
                    files.forEach((item, index) => {
                        formData.append("file" + index, item);
                    });
                }

                this.props.broadcastActions.sendBroadcastRequest(formData);
            }
        });
    };

    openPickerSelector = (files) => {
        this.props.navigator.showLightBox({
            screen: 'nactus.SelectorDialog',
            passProps: {
                title: Strings.attach_files,
                data: [
                    {title: Strings.take_picture, type: 1},
                    {title: Strings.pick_image_library, type: 2},
                    {title: Strings.pick_file_library, type: 3}
                ],
                onPress: (type) => {
                    if (type == 1)
                        this.openCameraPicker(files);
                    else if (type == 2)
                        this.openImagePicker(files);
                    else if (type == 3)
                        this.openDocumentPicker(files);
                }
            },
            style: {
                backgroundBlur: 'dark', // 'dark' / 'light' / 'xlight' / 'none' - the type of blur on the background
                backgroundColor: color.light_box_bg, // tint color for the background, you can specify alpha here (optional)
                tapBackgroundToDismiss: true // dismisses LightBox on background taps (optional)
            }
        })
    };

    openCameraPicker = (files) => {
        let options = {
            storageOptions: {
                skipBackup: true,
                path: 'images'
            },
            noData: true,
            mediaType: 'photo'
        };
        ImagePicker.launchCamera(options, (response) => {
            if (!response.didCancel && !response.error && !response.customButton) {
                response.name = isIOS ? "IMG_" + new Date().getTime() + ".jpg" : response.fileName;
                response.type = 'image/jpeg';
                this.setFile(files, response);
            }
        });
    };

    openImagePicker = (files) => {
        let options = {
            storageOptions: {
                skipBackup: true,
                path: 'images'
            },
            noData: true,
            mediaType: 'photo'
        };
        ImagePicker.launchImageLibrary(options, (response) => {
            if (!response.didCancel && !response.error && !response.customButton) {
                response.name = response.fileName;
                response.type = 'image/jpeg';
                this.setFile(files, response);
            }
        });
    };

    openDocumentPicker = (files) => {
        DocumentPicker.pick({
            type: [DocumentPicker.types.pdf, Utils.msword()],
        }).then(response => {
            if (response) {
                this.setFile(files, response);
            }
        }).catch(error => {

        });
    };

    setFile = (files, ...response) => {
        this.setState({
            files: [...response, ...files],
            fileError: undefined
        });
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: size.size_16
    },
    counter: {
        alignSelf: 'flex-end',
        paddingHorizontal: size.size_16,
        paddingVertical: size.size_2,
        color: color.white,
        fontSize: size.text_size_small,
        fontFamily: font.semibold
    },
    list: {
        flex: 1,
        margin: size.size_16
    },
    fileContainer: {
        height: '100%',
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5,
        backgroundColor: color.transparent
    },
    fileTitle: {
        color: color.white,
        fontSize: size.text_size_v_small,
        fontFamily: font.semibold
    }
});

function mapStateToProps(state) {
    return {
        broadcastData: state.sendBroadcastReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        broadcastActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(BroadcastMessages);