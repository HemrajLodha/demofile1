import React from "react";
import {Alert, StyleSheet, View} from "react-native";
import {connect} from "react-redux";
import * as actions from "../../../reducers/student/actions";
import {bindActionCreators} from "redux";
import color from "../../../../assets/values/color";
import size from "../../../../assets/values/dimens";
import font from "../../../../assets/values/font";
import Strings from "../../../../assets/strings/strings";
import {Utils} from "../../../utils/Utils";
import ProgressView from "../../../widget/ProgressView";
import ErrorView from "../../../widget/ErrorView";
import {RecyclerListView, DataProvider, LayoutProvider} from "recyclerlistview";
import {Avatar, ListItem} from "react-native-elements";
import FastImage from "react-native-fast-image";
import SearchView from "../../../widget/SearchView";


class BroadcastStudents extends React.Component {

    constructor(props) {
        super(props);
        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.screen_width / 5;
            }
        );

        this.state = {
            student: '',
        };

        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
    }

    onNavigatorEvent(event) {
        if (event.type == 'NavBarButtonPress') {
            if (event.id == 'next') {
                this.goToBroadcastMessages(this.props);
            }
        }
    }

    componentDidMount() {
        this.getStudentList(this.props);
    }

    componentWillUnmount() {
        this.props.studentActions.reset();
    }

    componentDidUpdate(prevProps, prevState) {
        let {studentData} = this.props;
        let prevStudentData = prevProps.studentData;
        if (studentData.isLoaded != prevStudentData.isLoaded) {
            this.showNextButton(!studentData.isLoaded)
        }
    }

    render() {
        let {studentData} = this.props;
        let {student} = this.state;
        student = new RegExp(student, 'i');
        let students = !studentData.isLoaded ? [] : studentData.data.filter(item => student.test(item.first_name));
        return (
            studentData.isLoading ? <ProgressView/> :
                Utils.isEmpty(studentData.data) ? studentData.message ?
                    <ErrorView error={studentData.message}/> : null :
                    <React.Fragment>
                        <ListItem containerStyle={[styles.listContainer, {height: -1}]}
                                  checkBox={{
                                      checked: studentData.checkAll,
                                      title: Strings.title_all,
                                      containerStyle: styles.checkboxContainer,
                                      textStyle: styles.checkboxText,
                                      checkedIcon: 'check-square',
                                      checkedColor: color.colorPrimary,
                                      onPress: this.onPressCheckAll
                                  }}
                                  leftElement={<SearchView
                                      ref={ref => this.searchBar = ref}
                                      container={styles.containerSearch}
                                      inputContainer={styles.inputContainerSearch}
                                      editable={studentData.isLoaded}
                                      placeholder={Strings.student_name}
                                      onChangeValue={text => this.setState({student: text})}
                                  />}
                        />
                        <RecyclerListView
                            layoutProvider={this.layoutProvider}
                            dataProvider={this.dataProvider.cloneWithRows(students)}
                            rowRenderer={this.rowRenderer.bind(this, studentData.url)}/>
                    </React.Fragment>
        );
    }

    rowRenderer = (url, type, data, index) => {
        return (
            <ListItem
                containerStyle={styles.listContainer}
                title={data.first_name}
                titleStyle={styles.listTitle}
                subtitle={"E.N. - " + data.enroll_id}
                subtitleStyle={styles.listSubtitle}
                checkBox={{
                    checked: data.is_selected,
                    containerStyle: styles.checkboxContainer,
                    textStyle: styles.checkboxText,
                    checkedIcon: 'check-square',
                    checkedColor: color.colorPrimary,
                    onPress: this.onPressCheck.bind(this, data, data.index)
                }}
                leftAvatar={Utils.isEmpty(data.image) ?
                    <Avatar
                        overlayContainerStyle={{backgroundColor: color.transparent}}
                        containerStyle={styles.image}
                        rounded
                        titleStyle={styles.iconTitle}
                        title={data.first_name.substring(0, 1).toUpperCase()}
                    /> :
                    <FastImage
                        style={styles.image}
                        source={{
                            uri: Utils.getImageUrl(url, data.student_id, data.image),
                            priority: FastImage.priority.normal,
                        }}
                        resizeMode={FastImage.resizeMode.cover}/>}
            />
        )
    };

    getStudentList = ({classIds}) => {
        let params = {
            class_id: classIds
        };
        this.props.studentActions.getStudentData(params);
    };

    onPressCheckAll = () => {
        this.props.studentActions.changeCheckAll();
    };

    onPressCheck = (data, position) => {
        data.is_selected = !data.is_selected;
        this.props.studentActions.changeCheck(data, position);
    };

    showNextButton = (disabled) => {
        this.props.navigator.setButtons({
            rightButtons: [
                {
                    id: 'next',
                    title: Strings.next,
                    disabled: disabled
                }
            ]
        })
    };

    goToBroadcastMessages = ({user, studentData, broadcast_type}) => {
        let studentIds = studentData.data
            .filter(item => item.is_selected)
            .map(item => item.student_id)
            .join(',');
        if (!Utils.isNull(studentIds)) {
            this.props.navigator.push({
                screen: 'nactus.BroadcastMessages',
                title: Strings.broadcast,
                backButtonTitle:"Back",
                passProps: {
                    user: user,
                    studentIds: studentIds,
                    broadcast_type: broadcast_type
                }
            });
        }
        else {
            Alert.alert(Strings.app_name, Strings.error_studentOption,
                [
                    {text: Strings.OK}
                ],
                {cancelable: false});
        }
    };
}

const styles = StyleSheet.create({
    listContainer: {
        height: "100%",
        backgroundColor: color.transparent,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5
    },
    listTitle: {
        color: color.white,
        fontSize: size.text_size_small,
        fontFamily: font.semibold
    },
    listSubtitle: {
        color: color.white,
        fontSize: size.text_size_vv_small,
        fontFamily: font.regular
    },
    checkboxContainer: {
        borderWidth: 0,
        backgroundColor: color.transparent,
    },
    checkboxText: {
        color: color.white,
        fontFamily: font.regular,
        fontWeight: '100',
        fontSize: size.text_size_v_small
    },
    image: {
        width: size.size_48,
        height: size.size_48,
        borderRadius: size.size_48 / 2,
        backgroundColor: color.light_box_bg,
        borderColor: color.gray_200,
        borderWidth: size.size_1
    },
    iconTitle: {
        color: color.white,
        fontFamily: font.semibold,
    },
    containerSearch: {
        flex: 1,
        marginTop: size.size_4,
    },
    inputContainerSearch: {
        marginHorizontal: size.size_4
    },
});

function mapStateToProps(state) {
    return {
        studentData: state.studentReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        studentActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(BroadcastStudents);