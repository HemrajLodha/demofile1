import React from "react";
import {Text, View, Alert} from "react-native";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import DashboardBar from "./toolbar/DashboardBar";
import DashboardItem, {DashboardItemType} from "./item/DashboardItem";
import size from "../../../assets/values/dimens";
import {Utils} from "../../utils/Utils";
import ProgressView from "../../widget/ProgressView";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import * as actions from "../../reducers/dashboard/actions";
import Strings from "../../../assets/strings/strings";
import ErrorView from "../../widget/ErrorView";
import DashboardProfile from "./profile/DashboardProfile";

const DashboardType = {
    TYPE_PROFILE: 1,
    TYPE_ITEM: 2,
};

class Dashboard extends React.Component {

    constructor(props) {
        super(props);

        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                switch (index) {
                    case 0:
                        return DashboardType.TYPE_PROFILE;
                    default:
                        return DashboardType.TYPE_ITEM;
                }
            },
            (type, dim) => {
                switch (type) {
                    case DashboardType.TYPE_PROFILE:
                        dim.width = size.screen_width - size.size_0_5;
                        dim.height = size.screen_height * 0.25;
                        break;
                    case DashboardType.TYPE_ITEM:
                        dim.width = size.screen_width * 0.5 - size.size_0_5;
                        dim.height = size.screen_height * 0.205;
                        break
                }
            }
        );

    }


    componentWillUnmount() {
        this.props.dashboardActions.reset();
    }

    componentDidMount() {
        this.getUserData(this.props)
    }

    render() {
        let {dashboardData, user} = this.props;
        return (
            dashboardData.isLoading ?
                <ProgressView/> :
                Utils.isEmpty(dashboardData.data) ?
                    dashboardData.message ?
                        <ErrorView error={dashboardData.message}/> : null :
                    <RecyclerListView
                        layoutProvider={this.layoutProvider}
                        dataProvider={this.dataProvider.cloneWithRows(dashboardData.data)}
                        rowRenderer={this.rowRenderer.bind(this, user)}/>
        );
    }

    rowRenderer = (user, type, data, index) => {
        switch (type) {
            case DashboardType.TYPE_PROFILE:
                return (
                    <DashboardProfile data={data} index={index}/>
                );
            case DashboardType.TYPE_ITEM:
                return (
                    <DashboardItem data={data} index={index} onPress={() => this.onPressItem(data.type, user)}/>
                );
        }
    };

    getUserData = ({user}) => {
        let params = {
            faculty_id: user.id
        };
        this.props.dashboardActions.getDashboardData(params);
    };

    onPressItem = (type, user) => {
        let data = {
            passProps: {
                user: user
            }
        };
        switch (type) {
            case DashboardItemType.TYPE_TAKE_ATTENDANCE:
                data.screen = "nactus.TakeAttendance";
                data.title = Strings.take_attendance;
                break;
            case DashboardItemType.TYPE_VIEW_ATTENDANCE:
                data.screen = "nactus.ViewAttendance";
                data.title = Strings.view_attendance;
                break;
            case DashboardItemType.TYPE_ADD_MARKS:
                data.screen = "nactus.AddExamDetail";
                data.title = Strings.add_marks;
                break;
            case DashboardItemType.TYPE_VIEW_MARKS:
                data.screen = "nactus.ViewMarks";
                data.title = Strings.view_marks;
                break;
            case DashboardItemType.TYPE_BROADCAST:
                data.screen = "nactus.Broadcast";
                data.title = Strings.broadcast;
                break;
            case DashboardItemType.TYPE_SETTINGS:
                data.screen = "nactus.Settings";
                data.title = Strings.settings;
                break;
        }

        this.props.navigator.push(data)
    }
}

function mapStateToProps(state) {
    return {
        dashboardData: state.dashboardReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        dashboardActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);