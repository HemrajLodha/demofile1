import React from "react";
import {Text, StyleSheet, TouchableOpacity} from "react-native";
import {Avatar, Card} from "react-native-elements";
import color from "../../../../assets/values/color";
import size from "../../../../assets/values/dimens";
import font from "../../../../assets/values/font";


export const DashboardItemType = {
    TYPE_TAKE_ATTENDANCE: "1",
    TYPE_VIEW_ATTENDANCE: "2",
    TYPE_ADD_MARKS: "3",
    TYPE_VIEW_MARKS: "4",
    TYPE_BROADCAST: "5",
    TYPE_SETTINGS: "6",
};

class DashboardItem extends React.Component {

    render() {
        let {data, index, onPress} = this.props;
        return (
            <TouchableOpacity style={styles.mainContainer}
                              onPress={onPress}>
                <Card
                    containerStyle={[styles.container]}
                    wrapperStyle={styles.wrapper}>

                    <Avatar source={data.icon}
                            containerStyle={styles.avatarContainer}
                            avatarStyle={styles.avatar}
                            overlayContainerStyle={styles.overlayContainer}
                            imageProps={{
                                resizeMode: 'contain',
                            }}
                    />

                    <Text style={styles.title}>
                        {data.title}
                    </Text>
                </Card>
            </TouchableOpacity>
        );
    }
}

const styles = StyleSheet.create({
    mainContainer: {
        flex: 1,
    },
    container: {
        flex: 1,
        backgroundColor: color.transparent,
        margin: 0,
        padding: 0,
        justifyContent: 'center',
        alignItems: 'center',
        borderColor: color.white,
        borderWidth: size.size_0_5
    },
    wrapper: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    title: {
        fontSize: size.text_size_small,
        color: color.textColor,
        fontFamily: font.semibold,
        marginTop: size.size_8
    },
    avatarContainer: {},
    avatar: {
        tintColor: color.white
    },
    overlayContainer: {
        backgroundColor: color.transparent,
    }
});

export default DashboardItem;