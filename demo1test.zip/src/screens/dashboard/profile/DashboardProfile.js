import React from 'react';
import {StyleSheet, Text, View} from "react-native";
import {Avatar, Card, Icon, ListItem} from "react-native-elements";
import color from "../../../../assets/values/color";
import size from "../../../../assets/values/dimens";
import font from "../../../../assets/values/font";
import FastImage from "react-native-fast-image";
import {Utils} from "../../../utils/Utils";

class DashboardProfile extends React.Component {

    render() {
        let {data} = this.props;
        return (
            <Card
                containerStyle={[styles.container]}
                wrapperStyle={styles.wrapper}>
                <ListItem
                    containerStyle={[styles.itemContainer]}
                    leftAvatar={Utils.isEmpty(data.InstituteData.image_url) ? <Avatar
                        overlayContainerStyle={{backgroundColor: color.transparent}}
                        containerStyle={styles.image}
                        rounded
                        titleStyle={styles.imageTitle}
                        title={data.name.substring(0, 1).toUpperCase()}
                    /> : <FastImage
                        style={styles.image}
                        source={{
                            uri: data.InstituteData.image_url,
                            priority: FastImage.priority.normal,
                        }}
                        resizeMode={FastImage.resizeMode.cover}/>}
                    title={data.InstituteData.first_name}
                    titleStyle={styles.title}
                    subtitle={<View style={styles.subtitleContainer}>
                        <Icon name={'phone'}
                              color={color.white}
                              size={size.text_size_small}/>
                        <Text style={styles.subtitle}>{data.mobile}</Text>
                    </View>}

                >

                </ListItem>
                <View style={styles.nameContainer}>
                    <Text style={styles.name}>
                        {
                            "Welcome " + data.name
                        }
                    </Text>
                </View>
            </Card>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: color.transparent,
        margin: 0,
        padding: 0,
        borderColor: color.white,
        borderWidth: size.size_0_5,
    },
    wrapper: {
        flex: 1,
        justifyContent: 'space-between'
    },
    itemContainer: {
        backgroundColor: color.transparent,
    },
    image: {
        width: size.size_75,
        height: size.size_75,
        borderRadius: size.size_75 / 2,
        backgroundColor: color.light_box_bg,
        borderColor: color.gray_200,
        borderWidth: size.size_1
    },
    imageTitle: {
        color: color.white,
        fontFamily: font.semibold,
    },
    nameContainer: {
        height: size.size_36,
        backgroundColor: color.light_box_bg,
        justifyContent: 'center',
        paddingHorizontal: size.size_16
    },
    name: {
        color: color.white,
        fontFamily: font.semibold,
        fontSize: size.text_size_v_medium,
    },
    title: {
        alignSelf: 'flex-end',
        color: color.white,
        fontFamily: font.semibold,
        fontSize: size.text_size_v_medium
    },
    subtitle: {
        color: color.white,
        fontFamily: font.regular,
        marginLeft: size.size_8,
        fontSize: size.text_size_v_small
    },
    subtitleContainer: {
        flexDirection: 'row',
        alignSelf: 'flex-end',
        alignItems: 'center'
    }
});

export default DashboardProfile;