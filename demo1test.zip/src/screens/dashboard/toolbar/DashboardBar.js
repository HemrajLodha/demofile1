import React from "react";
import {Image, StyleSheet, View} from "react-native";
import size from "../../../../assets/values/dimens";
import color from "../../../../assets/values/color";
import {Icon} from "react-native-elements";
import {logout} from "../../../store/asyncStoragedata";
import {navigateToApp} from "../../../App";

class DashboardBar extends React.Component {
    render() {
        return (
            <View style={styles.toolbarContainer}>
                <Image
                    style={styles.logo}
                    resizeMode={'contain'}
                    source={require('../../../../assets/images/ic_logo.png')}/>

                <Icon
                    containerStyle={styles.icon}
                    name={'sign-out'}
                    type={'font-awesome'}
                    color={color.white}
                    underlayColor={color.transparent}
                    onPress={this.logoutUser}/>
            </View>
        );
    }

    logoutUser = () => {
        logout()
            .then(() => navigateToApp())
            .catch(err => console.log(err));
    }
}

const styles = StyleSheet.create({
    toolbarContainer: {
        flexDirection: 'row',
        height: size.toolbar_height,
        justifyContent: 'space-between',
    },
    logo: {
        width: size.size_80,
        height: size.toolbar_height,
        tintColor: color.white,
        marginTop: size.size_4
    },
    icon: {
        width: size.toolbar_height,
        height: size.toolbar_height,
        justifyContent: 'center',
        alignItems: 'center'
    }
});

export default DashboardBar;