import React from "react";
import {Card, ListItem} from "react-native-elements";
import {StyleSheet} from "react-native";
import size from "../../../assets/values/dimens";
import color from "../../../assets/values/color";
import font from "../../../assets/values/font";
import IconView from "../../widget/IconView";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import Strings from "../../../assets/strings/strings";


class SelectorDialog extends React.Component {

    constructor(props) {
        super(props);
        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.size_48;
            }
        );

    }

    render() {
        let {data, onPress, title} = this.props;

        return (
            <Card containerStyle={styles.container}
                  wrapperStyle={styles.wrapper}
                  title={title}
                  titleStyle={styles.title}>

                <RecyclerListView
                    style={styles.list}
                    layoutProvider={this.layoutProvider}
                    dataProvider={this.dataProvider.cloneWithRows(data)}
                    rowRenderer={this.rowRenderer.bind(this, onPress)}/>

                <IconView onPress={this.doClose}/>
            </Card>
        );
    }


    rowRenderer = (onPress, type, data) => {
        return (
            <ListItem containerStyle={styles.listItemContainer}
                      title={data.title}
                      titleStyle={styles.titleItem}
                      onPress={() => {
                          this.doClose();
                          onPress(data.type)
                      }}
            />
        )
    };

    doClose = () => {
        this.props.navigator.dismissLightBox()
    };

}

const styles = StyleSheet.create({
    container: {
        width: size.screen_width * 0.9,
        height: size.screen_height * 0.4,
        backgroundColor: color.white,
        margin: 0
    },
    wrapper: {
        flex: 1,
        marginBottom: size.size_12,
    },
    title: {
        color: color.colorPrimary,
        fontSize: size.text_size_small,
        fontFamily: font.semibold,
        marginHorizontal: size.size_12,
    },
    list: {
        flex: 1
    },
    listItemContainer: {
        height: "100%",
        backgroundColor: color.transparent,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5
    },
    titleItem: {
        color: color.gray_700,
        fontFamily: font.bold,
        fontSize: size.text_size_small
    },
});

export default SelectorDialog;