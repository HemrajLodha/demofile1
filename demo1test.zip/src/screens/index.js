import {Navigation} from "react-native-navigation";
import Login from "./login/Login";
import Dashboard from "./dashboard/Dashboard";
import DashboardBar from "./dashboard/toolbar/DashboardBar";
import TakeAttendance from "./attendance/take/TakeAttendance";
import ViewAttendance from "./attendance/view/ViewAttendance";
import ViewMarks from "./marks/view/ViewMarks";
import Broadcast from "./broadcast/Broadcast";
import Settings from "./settings/Settings";
import EditPasswordSettings from "./settings/edit/EditPasswordSettings";
import AddExamDetail from "./marks/add/AddExamDetail";
import AddExamMarks from "./marks/add/AddExamMarks";
import SearchStudent from "./attendance/student/dialog/SearchStudent";
import ProgressView from "../widget/ProgressView";
import BroadcastClasses from "./broadcast/class/BroadcastClasses";
import BroadcastStudents from "./broadcast/student/BroadcastStudents";
import BroadcastMessages from "./broadcast/message/BroadcastMessages";
import SelectorDialog from "./dialog/SelectorDialog";
import CheckUsername from "./login/forgot/CheckUsername";
import UpdatePassword from "./login/forgot/UpdatePassword";
import VerifyOTP from "./login/forgot/VerifyOTP";
import NactusWebView from "./webview/NactusWebView";


export function registerScreens(store, provider) {
    Navigation.registerComponent('nactus.Login', () => Login, store, provider);
    Navigation.registerComponent('nactus.CheckUsername', () => CheckUsername, store, provider);
    Navigation.registerComponent('nactus.VerifyOTP', () => VerifyOTP, store, provider);
    Navigation.registerComponent('nactus.UpdatePassword', () => UpdatePassword, store, provider);
    Navigation.registerComponent('nactus.DashboardBar', () => DashboardBar);
    Navigation.registerComponent('nactus.Dashboard', () => Dashboard, store, provider);
    Navigation.registerComponent('nactus.TakeAttendance', () => TakeAttendance, store, provider);
    Navigation.registerComponent('nactus.ViewAttendance', () => ViewAttendance, store, provider);
    Navigation.registerComponent('nactus.SearchStudent', () => SearchStudent);
    Navigation.registerComponent('nactus.AddExamDetail', () => AddExamDetail, store, provider);
    Navigation.registerComponent('nactus.AddExamMarks', () => AddExamMarks, store, provider);
    Navigation.registerComponent('nactus.ViewMarks', () => ViewMarks, store, provider);
    Navigation.registerComponent('nactus.Broadcast', () => Broadcast, store, provider);
    Navigation.registerComponent('nactus.SelectorDialog', () => SelectorDialog);
    Navigation.registerComponent('nactus.BroadcastClasses', () => BroadcastClasses, store, provider);
    Navigation.registerComponent('nactus.BroadcastStudents', () => BroadcastStudents, store, provider);
    Navigation.registerComponent('nactus.BroadcastMessages', () => BroadcastMessages, store, provider);
    Navigation.registerComponent('nactus.Settings', () => Settings, store, provider);
    Navigation.registerComponent('nactus.EditPasswordSettings', () => EditPasswordSettings, store, provider);
    Navigation.registerComponent('nactus.ProgressView', () => ProgressView);
    Navigation.registerComponent('nactus.NactusWebView', () => NactusWebView);
}