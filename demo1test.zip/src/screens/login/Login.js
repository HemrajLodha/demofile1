import React from "react";
import {Image, Platform, Text, TouchableOpacity, View, Linking, Alert} from "react-native";
import {Icon} from "react-native-elements";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import styles from "./styles";
import Strings from "../../../assets/strings/strings";
import InputView from "../../widget/InputView";
import ButtonView from "../../widget/ButtonView";
import size from "../../../assets/values/dimens";
import color from "../../../assets/values/color";
import {validate} from "../../utils/ValidateUtils";
import * as actions from "../../reducers/login/actions";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {Utils} from "../../utils/Utils";
import {navigateToApp} from "../../App";
import Snackbar from "react-native-snackbar";
import {privacy_base_url, terms_base_url} from "../../api/api";

class Login extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            userName: undefined,
            password: undefined,
            userNameError: undefined,
            passwordError: undefined
        };
    }

    componentDidUpdate(prevProps) {
        let {loginData} = this.props;
        let oldData = prevProps.loginData;
        if (loginData === oldData)
            return;
        if (!Utils.isNull(loginData.data)) {
            navigateToApp();
            return;
        }

        loginData.message && Snackbar.show({
            title: loginData.message,
            duration: Snackbar.LENGTH_SHORT,
            backgroundColor: color.colorPrimary
        });
    }

    componentWillUnmount() {
        this.props.loginActions.reset();
    }

    componentDidMount() {
        let {logoutMessage} = this.props;
        logoutMessage && Snackbar.show({
            title: logoutMessage,
            duration: Snackbar.LENGTH_INDEFINITE,
            backgroundColor: color.colorPrimary,
            action: {
                title: Strings.OK,
                color: color.white,
            }
        });
    }

    render() {
        let {loginData} = this.props;
        let {userNameError, passwordError} = this.state;
        return (
            <KeyboardAwareScrollView style={styles.container}
                                     bounces={false}
            >
                <View style={styles.logoContainer}>
                    <Image
                        style={styles.logo}
                        resizeMode={'contain'}
                        source={require('../../../assets/images/ic_logo.png')}/>
                </View>
                <View style={styles.inputContainer}>
                    <InputView
                        ref={ref => this.userName = ref}
                        iconName={'account-outline'}
                        iconType={'material-community'}
                        placeholder={Strings.user_name}
                        errorMessage={userNameError}
                        editable={!loginData.isLogin}
                        onChangeValue={text => this.setState({userName: text})}
                        onSubmitEditing={(event) => {
                            this.password.focus();
                        }}/>

                    <InputView
                        ref={ref => this.password = ref}
                        iconName={'lock-outline'}
                        iconType={'material-community'}
                        placeholder={Strings.password}
                        showPassword={true}
                        editable={!loginData.isLogin}
                        errorMessage={passwordError}
                        returnKeyType={'done'}
                        onChangeValue={text => this.setState({password: text})}
                    />

                    <TouchableOpacity style={styles.forgotContainer}
                                      onPress={this.goToCheckUsername}>
                        <Icon name='lock-open'
                              iconType={'material-community'}
                              size={size.text_size_v_small}
                              color={color.white}/>

                        <Text style={styles.forgot}>
                            {Strings.forgot_password}
                            {" ?"}
                        </Text>
                    </TouchableOpacity>
                </View>
                <ButtonView title={Strings.sign_in.toUpperCase()}
                            loading={loginData.isLogin}
                            onPress={() => this.doLogin(this.state)}/>

                <Text style={styles.note}>
                    {
                        Strings.login_note
                    }
                    <Text style={styles.url}
                          onPress={() => this.goToWebView(Strings.terms, terms_base_url)}>
                        {Strings.terms}
                    </Text>
                    {
                        Strings.and
                    }
                    <Text style={styles.url}
                          onPress={() => this.goToWebView(Strings.privacy, privacy_base_url)}>
                        {Strings.privacy}
                    </Text>
                    {
                        Strings.nactus
                    }
                </Text>

            </KeyboardAwareScrollView>
        );
    }

    doLogin = ({userName, password}) => {
        let userNameError = validate('userName', userName);
        let passwordError = validate('password', password);
        this.setState({
            userNameError: userNameError,
            passwordError: passwordError
        }, () => {
            if (!userNameError && !passwordError) {
                let params = {
                    username: userName,
                    password: password,
                    device_type: Platform.OS
                };
                this.props.loginActions.doLoginRequest(params);
            }
        });
    };

    goToCheckUsername = () => {
        this.props.navigator.push({
            screen: 'nactus.CheckUsername',
            title: Strings.forgot_password
        })
    };

    goToWebView = (title, url) => {
        this.props.navigator.push({
            screen: 'nactus.NactusWebView',
            title: title,
            passProps: {
                url: url
            }
        })
    };

}

function mapStateToProps(state) {
    return {
        loginData: state.loginReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        loginActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Login);