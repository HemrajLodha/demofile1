import React from "react";
import {Image, StyleSheet, View, Alert} from "react-native";
import size from "../../../../assets/values/dimens";
import Strings from "../../../../assets/strings/strings";
import color from "../../../../assets/values/color";
import InputView from "../../../widget/InputView";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import font from "../../../../assets/values/font";
import ButtonView from "../../../widget/ButtonView";
import {validate} from "../../../utils/ValidateUtils";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import * as userActions from "../../../reducers/checkUsername/actions";
import Snackbar from "react-native-snackbar";
import {navigateToApp} from "../../../App";
import {Utils} from "../../../utils/Utils";
import * as otpActions from "../../../reducers/sendOTP/actions";
import {API_KEY, APP_KEY, COUNTRY_CODE, SMS} from "../../../api/api";
import TimerDisplay from "../../../widget/TimerDisplay";


class CheckUsername extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,
            userName: undefined,
            userNameError: undefined,
        };
        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));
    }

    onNavigatorEvent(event) {
        switch (event.id) {
            case 'willAppear':
                break;
            case 'didAppear':
                this.setState({isVisible: true});
                break;
            case 'willDisappear':
                break;
            case 'didDisappear':
                this.setState({isVisible: false});
                break;
            case 'willCommitPreview':
                break;
        }
    }

    componentWillUnmount() {
        this.props.userActions.reset();
        this.props.otpActions.reset();
    }

    componentDidUpdate(prevProps) {
        let {isVisible} = this.state;
        let {userData, otpData} = this.props;
        let prevUserData = prevProps.userData;
        let prevOtpData = prevProps.otpData;
        if (isVisible && userData !== prevUserData) {
            if (!Utils.isNull(userData.data)) {
                this.doSendOTP(userData.data, SMS);
                return;
            }
            userData.message && Snackbar.show({
                title: userData.message,
                duration: Snackbar.LENGTH_SHORT,
                backgroundColor: color.colorPrimary
            });
        }
        if (isVisible && otpData !== prevOtpData) {
            if (!Utils.isNull(otpData.data)) {
                this.goToVerifyOTP(userData.data);
            }
            otpData.message && Snackbar.show({
                title: otpData.message,
                duration: Snackbar.LENGTH_SHORT,
                backgroundColor: color.colorPrimary
            });
        }
    }

    render() {
        let {userData, otpData} = this.props;
        let {userNameError} = this.state;
        return (
            <KeyboardAwareScrollView style={styles.container} bounces={false}>
                <View style={styles.logoContainer}>
                    <Image
                        style={styles.logo}
                        resizeMode={'contain'}
                        source={require('../../../../assets/images/ic_logo.png')}/>
                </View>
                <View style={styles.inputContainer}>
                    <InputView
                        ref={ref => this.userName = ref}
                        returnKeyType={'done'}
                        iconName={'account-outline'}
                        iconType={'material-community'}
                        placeholder={Strings.user_name}
                        errorMessage={userNameError}
                        editable={!userData.isChecking || !otpData.isSending}
                        onChangeValue={text => this.setState({userName: text})}
                    />

                </View>
                <ButtonView title={Strings.submit.toUpperCase()}
                            loading={userData.isChecking || otpData.isSending}
                            onPress={() => this.doCheckUsername(this.state)}/>
            </KeyboardAwareScrollView>
        );
    }

    doCheckUsername = ({userName}) => {
        let userNameError = validate('userName', userName);
        this.setState({
            userNameError: userNameError
        }, () => {
            if (!userNameError) {
                let params = {
                    username: userName,
                };
                this.props.userActions.doCheckUsernameRequest(params);
            }
        });
    };

    doSendOTP = (userData, service) => {
        let params = {
            app_key: APP_KEY,
            api_key: API_KEY,
            phone: COUNTRY_CODE + userData.mobile,
            service: service,
        };
        this.props.otpActions.doSendOTPRequest(params)
    };

    goToVerifyOTP = (data) => {
        this.props.navigator.push({
            screen: 'nactus.VerifyOTP',
            title: Strings.verify_user,
            passProps: {
                userData: data
            }
        })
    }
}

const styles = StyleSheet.create({
    container: {},
    logoContainer: {
        width: size.screen_width,
        height: size.screen_width * 0.5,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    logo: {
        width: size.screen_width * 0.6,
    },
    inputContainer: {
        marginTop: size.size_48
    },
});

function mapStateToProps(state) {
    return {
        userData: state.checkUsernameReducer,
        otpData: state.sendOTPReducer,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        userActions: bindActionCreators(userActions, dispatch),
        otpActions: bindActionCreators(otpActions, dispatch),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(CheckUsername);