import Strings from "../../../../assets/strings/strings";
import {Alert, Image, View, StyleSheet} from "react-native";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import React from "react";
import size from "../../../../assets/values/dimens";
import InputView from "../../../widget/InputView";
import ButtonView from "../../../widget/ButtonView";
import {validate, validatePassword} from "../../../utils/ValidateUtils";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/editPassword/actions";
import {connect} from "react-redux";

class UpdatePassword extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            newPasswordError: undefined,
            newPassword: undefined,
            confirmPasswordError: undefined,
            confirmPassword: undefined,
        };
    }


    componentWillUnmount() {
        this.props.editPasswordActions.reset();
    }

    componentDidUpdate(prevProps) {
        let {editPasswordData, navigator} = this.props;
        let prevEditPasswordData = prevProps.editPasswordData;
        if (editPasswordData !== prevEditPasswordData) {
            editPasswordData.message && Alert.alert(Strings.app_name, editPasswordData.message,
                [
                    {text: Strings.OK, onPress: editPasswordData.isUpdated ? () => navigator.popToRoot() : undefined}
                ],
                {cancelable: !editPasswordData.isUpdated});
        }
    }


    render() {
        let {editPasswordData, userData} = this.props;
        let {newPasswordError, confirmPasswordError} = this.state;
        return (
            <KeyboardAwareScrollView style={styles.container} bounces={false}>
                <View style={styles.logoContainer}>
                    <Image
                        style={styles.logo}
                        resizeMode={'contain'}
                        source={require('../../../../assets/images/ic_logo.png')}/>
                </View>
                <View style={styles.inputContainer}>
                    <InputView
                        ref={ref => this.newPassword = ref}
                        iconName={'lock-outline'}
                        iconType={'material-community'}
                        placeholder={Strings.new_password}
                        showPassword={true}
                        editable={!editPasswordData.isUpdating}
                        errorMessage={newPasswordError}
                        onChangeValue={text => this.setState({newPassword: text})}
                        onSubmitEditing={(event) => {
                            this.confirmPassword.focus();
                        }}
                    />

                    <InputView
                        ref={ref => this.confirmPassword = ref}
                        iconName={'lock-outline'}
                        iconType={'material-community'}
                        placeholder={Strings.confirm_password}
                        showPassword={true}
                        editable={!editPasswordData.isUpdating}
                        errorMessage={confirmPasswordError}
                        returnKeyType={'done'}
                        onChangeValue={text => this.setState({confirmPassword: text})}
                    />

                </View>

                <ButtonView
                    title={Strings.title_update}
                    loading={editPasswordData.isUpdating}
                    onPress={() => this.doUpdatePassword(this.state, userData)}/>
            </KeyboardAwareScrollView>
        );
    }

    doUpdatePassword = ({newPassword, confirmPassword}, userData) => {
        let newPasswordError = validate('newPassword', newPassword);
        let confirmPasswordError = validatePassword('confirmPassword', newPassword, confirmPassword);
        this.setState({
            newPasswordError: newPasswordError,
            confirmPasswordError: confirmPasswordError,
        }, () => {
            if (!newPasswordError && !confirmPasswordError && userData) {
                let params = {
                    faculty_id: userData.id,
                    new_password: newPassword,
                    confirm_password: confirmPassword,
                };

                this.props.editPasswordActions.doUpdatePasswordRequest(params);
            }
        });
    };

}


const styles = StyleSheet.create({
    container: {
    },
    logoContainer: {
        width: size.screen_width,
        height: size.screen_width * 0.5,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    logo: {
        width: size.screen_width * 0.6,
    },
    inputContainer: {},
});

function mapStateToProps(state) {
    return {
        editPasswordData: state.editPasswordReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        editPasswordActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(UpdatePassword);