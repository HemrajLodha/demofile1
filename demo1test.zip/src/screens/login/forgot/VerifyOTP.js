import React from "react";
import {Image, StyleSheet, View, Alert, Text} from "react-native";
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import * as otpActions from "../../../reducers/sendOTP/actions";
import * as verifyActions from "../../../reducers/verifyOTP/actions";
import Strings from "../../../../assets/strings/strings";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import InputView from "../../../widget/InputView";
import ButtonView from "../../../widget/ButtonView";
import {validate} from "../../../utils/ValidateUtils";
import color from "../../../../assets/values/color";
import size from "../../../../assets/values/dimens";
import {API_KEY, APP_KEY, COUNTRY_CODE, SMS} from "../../../api/api";
import ProgressView from "../../../widget/ProgressView";
import TimerDisplay from "../../../widget/TimerDisplay";
import Snackbar from "react-native-snackbar";
import {Utils} from "../../../utils/Utils";
import font from "../../../../assets/values/font";

class VerifyOTP extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            otp: undefined,
            otpError: undefined,
        };
    }

    componentWillUnmount() {
        this.props.otpActions.reset();
        this.props.verifyActions.reset();
    }

    componentDidUpdate(prevProps) {
        let {otpData, verifyData, userData} = this.props;
        let prevOtpData = prevProps.otpData;
        let prevVerifyData = prevProps.verifyData;
        if (otpData !== prevOtpData) {
            otpData.message && Snackbar.show({
                title: otpData.message,
                duration: Snackbar.LENGTH_SHORT,
                backgroundColor: color.colorPrimary
            });
        }
        if (verifyData !== prevVerifyData) {
            if (!Utils.isNull(verifyData.data)) {
                this.goToUpdatePassword(userData);
                return;
            }
            verifyData.message && Snackbar.show({
                title: verifyData.message,
                duration: Snackbar.LENGTH_SHORT,
                backgroundColor: color.colorPrimary
            });
        }
    }

    render() {
        let {otpData, verifyData, userData} = this.props;
        let {otpError} = this.state;
        return (
            <KeyboardAwareScrollView style={styles.container} bounces={false}>
                <View style={styles.logoContainer}>
                    <Image
                        style={styles.logo}
                        resizeMode={'contain'}
                        source={require('../../../../assets/images/ic_logo.png')}/>

                    {
                        otpData.data &&
                        <Text style={styles.message}>
                            {Utils.stringReplace(Strings.message_otp, [COUNTRY_CODE + userData.mobile])}
                        </Text>
                    }
                </View>
                <View style={styles.inputContainer}>
                    <InputView
                        ref={ref => this.otp = ref}
                        returnKeyType={'done'}
                        iconName={'message'}
                        iconType={'material-community'}
                        placeholder={Strings.otp}
                        errorMessage={otpError}
                        editable={!verifyData.isSending}
                        onChangeValue={text => this.setState({otp: text})}
                    />

                    <TimerDisplay
                        style={styles.timer}
                        isSending={otpData.isSending}
                        duration={otpData.retry_in || 0}
                        onPress={() => this.doResendOTP()}/>

                </View>
                <ButtonView title={Strings.verify.toUpperCase()}
                            loading={verifyData.isSending}
                            onPress={() => this.doVerifyOTP(this.state, otpData.data)}/>
            </KeyboardAwareScrollView>
        );
    }

    doResendOTP = () => {
        this.doSendOTP(this.props, SMS);
    };

    doSendOTP = ({userData, otpData}, service) => {
        let params = {
            app_key: APP_KEY,
            api_key: API_KEY,
            phone: COUNTRY_CODE + userData.mobile,
            service: service,
        };
        if (otpData.data)
            params.token = otpData.data.token;

        this.props.otpActions.doSendOTPRequest(params)
    };

    doVerifyOTP = ({otp}, data) => {
        let otpError = validate('otp', otp);
        this.setState({
            otpError: otpError
        }, () => {
            if (!otpError && data) {
                let params = {
                    app_key: APP_KEY,
                    api_key: API_KEY,
                    code: otp,
                    token: data.token,
                };
                this.props.verifyActions.doVerifyOTPRequest(params)
            }
        });
    };

    goToUpdatePassword = (data) => {
        this.props.navigator.push({
            screen: 'nactus.UpdatePassword',
            title: Strings.update_password,
            passProps: {
                userData: data
            }
        })
    }
}

const styles = StyleSheet.create({
    container: {},
    logoContainer: {
        width: size.screen_width,
        height: size.screen_width * 0.5,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    logo: {
        width: size.screen_width * 0.6,
    },
    message: {
        color: color.white,
        marginVertical: size.size_24,
        fontFamily: font.semibold,
        fontSize: size.text_size_small,
        textAlign: 'center'
    },
    inputContainer: {},
    timer: {
        marginHorizontal: size.size_24,
        marginTop: size.size_16
    }
});

function mapStateToProps(state) {
    return {
        otpData: state.sendOTPReducer,
        verifyData: state.verifyOTPReducer,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        otpActions: bindActionCreators(otpActions, dispatch),
        verifyActions: bindActionCreators(verifyActions, dispatch),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(VerifyOTP);

