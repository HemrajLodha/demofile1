import {StyleSheet} from "react-native";
import color from "../../../assets/values/color";
import size from "../../../assets/values/dimens";
import font from "../../../assets/values/font";

const styles = StyleSheet.create({
    container: {
        flex: 1
    },
    logoContainer: {
        width: size.screen_width,
        height: size.screen_width * 0.45,
        justifyContent: 'flex-end',
        alignItems: 'center',
    },
    logo: {
        width: size.screen_width * 0.6,
    },
    inputContainer: {
        marginTop: size.size_48
    },
    forgotContainer: {
        flexDirection: 'row',
        alignSelf: 'flex-end',
        paddingVertical: size.size_8,
        marginRight: size.size_36
    },
    forgot: {
        color: color.textColor,
        fontSize: size.text_size_v_small,
        fontFamily: font.semibold
    },
    note: {
        marginTop: size.size_24,
        color: color.textColor,
        textAlign: 'center',
        fontSize: size.text_size_small,
        fontFamily: font.semibold
    },
    url: {
        color: color.colorPrimary,
        fontSize: size.text_size_small,
        fontFamily: font.semibold,
        textDecorationLine: 'underline'
    }
});

export default styles;