import React from "react";
import {StyleSheet, Text, View, Alert} from "react-native";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/class/actions";
import * as subjectActions from "../../../reducers/subject/actions";
import {connect} from "react-redux";
import Strings from "../../../../assets/strings/strings";
import {Utils} from "../../../utils/Utils";
import ProgressView from "../../../widget/ProgressView";
import {MenuProvider} from "react-native-popup-menu";
import PopupMenu from "../../../widget/PopupMenu";
import DatePickerView from "../../../widget/DatePickerView";
import size from "../../../../assets/values/dimens";
import InputView from "../../../widget/InputView";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import ButtonView from "../../../widget/ButtonView";
import {validate} from "../../../utils/ValidateUtils";
import color from "../../../../assets/values/color";
import Snackbar from "react-native-snackbar";


class AddExamDetail extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            classOption: undefined,
            classOptionError: undefined,
            subjectOption: undefined,
            subjectOptionError: undefined,
            testName: undefined,
            testNameError: undefined,
            testDate: new Date(),
            testDateError: undefined,
            maxMarks: undefined,
            maxMarksError: undefined,
        }
    }

    componentDidMount() {
        this.getClassList(this.props);
    }

    componentWillUnmount() {
        Snackbar.dismiss();
        this.props.classActions.reset();
        this.props.subjectActions.reset();
    }

    componentDidUpdate(prevProps, prevState) {
        let {classOption} = this.state;
        let prevClassOption = prevState.classOption;
        if (classOption !== prevClassOption) {
            this.setState({
                subjectOption: undefined
            }, () => {
                if (classOption && classOption.is_mark) {
                    Snackbar.dismiss();
                    this.getSubjectList(classOption);
                }
                else {
                    Snackbar.show({
                        title: Strings.permission_add_marks,
                        duration: Snackbar.LENGTH_INDEFINITE,
                        backgroundColor: color.colorPrimary,
                        action: {
                            title: Strings.OK,
                            color: color.white,
                        }
                    })
                }
            });
        }
    }

    render() {
        let {classData, subjectData, user, navigator} = this.props;
        let {testDate, classOption, subjectOption, classOptionError, subjectOptionError, testNameError, testDateError, maxMarksError} = this.state;
        return (
            <MenuProvider style={styles.container}>
                <KeyboardAwareScrollView bounces={false}>
                    <PopupMenu
                        placeHolder={{title: Strings.select_class, class_id: "-1"}}
                        options={classData.data}
                        loading={classData.isLoading}
                        disabled={Utils.isEmpty(classData.data)}
                        selectedKey={'class_id'}
                        selectedTitle={'title'}
                        selected={classOption ? classOption.class_id : undefined}
                        error={classOptionError}
                        onSelect={this.doFilterClass}/>

                    <PopupMenu
                        placeHolder={{name: Strings.select_subject, id: "-1"}}
                        options={subjectData.data}
                        loading={subjectData.isLoading}
                        disabled={classOption && !classOption.is_mark || Utils.isEmpty(subjectData.data)}
                        selectedKey={'id'}
                        selectedTitle={'name'}
                        selected={subjectOption ? subjectOption.id : undefined}
                        error={subjectOptionError}
                        onSelect={this.doFilterSubject}/>

                    <InputView
                        ref={ref => this.testName = ref}
                        container={styles.containerTest}
                        inputContainer={styles.inputContainerTest}
                        placeholder={Strings.test_name}
                        errorMessage={testNameError}
                        isLabel={false}
                        returnKeyType={'done'}
                        onChangeValue={text => this.setState({testName: text})}
                        underline={false}/>

                    <DatePickerView
                        ref={ref => this.datePicker = ref}
                        isRight={true}
                        placeholder={Strings.test_date}
                        date={testDate}
                        container={styles.containerDate}
                        errorMessage={testDateError}
                        inputContainer={styles.inputContainerDate}
                        onPick={date => this.setState({testDate: date})}
                    />

                    <InputView
                        ref={ref => this.maxMarks = ref}
                        container={styles.containerTest}
                        inputContainer={styles.inputContainerTest}
                        placeholder={Strings.max_marks}
                        errorMessage={maxMarksError}
                        keyboardType={'numeric'}
                        returnKeyType={'done'}
                        isLabel={false}
                        underline={false}
                        onChangeValue={text => this.setState({maxMarks: text})}/>
                </KeyboardAwareScrollView>
                <ButtonView
                    style={styles.button}
                    title={Strings.next}
                    disabled={classOption && !classOption.is_mark}
                    onPress={() => this.goToAddMarks(this.state, user, navigator)}/>
            </MenuProvider>
        );
    }

    getClassList = ({user}) => {
        let params = {
            user_member_id: user.id,
            status: 2
        };
        this.props.classActions.getClassData(params);
    };

    getSubjectList = (classOption) => {
        if (classOption) {
            let params = {
                class_id: classOption.class_id
            };
            this.props.subjectActions.getSubjectData(params);
        }
        else {
            this.props.subjectActions.reset();
        }
    };

    doFilterClass = (option) => {
        this.setState({
            classOption: option
        })
    };

    doFilterSubject = (option) => {
        this.setState({
            subjectOption: option
        })
    };

    goToAddMarks = ({classOption, subjectOption, testName, testDate, maxMarks}, user, navigator) => {
        let classOptionError = validate('classOption', classOption);
        let subjectOptionError = validate('subjectOption', subjectOption);
        let testNameError = validate('testName', testName);
        let testDateError = validate('testDate', testDate);
        let maxMarksError = validate('maxMarks', maxMarks);

        this.setState({
            classOptionError: classOptionError,
            subjectOptionError: subjectOptionError,
            testNameError: testNameError,
            testDateError: testDateError,
            maxMarksError: maxMarksError,
        }, () => {
            if (!classOptionError && !subjectOptionError && !testNameError && !testDateError && !maxMarksError) {
                navigator.push({
                    screen: 'nactus.AddExamMarks',
                    title: Strings.add_marks,
                    passProps: {
                        user: user,
                        classOption: classOption,
                        subjectOption: subjectOption,
                        testName: testName,
                        testDate: testDate,
                        maxMarks: maxMarks,
                    }
                });
            }
        });


    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    dateSearchContainer: {
        flexDirection: 'row'
    },
    containerTest: {
        marginTop: size.size_4,
    },
    inputContainerTest: {
        marginHorizontal: size.size_4
    },
    containerDate: {
        marginTop: size.size_4,
    },
    inputContainerDate: {
        marginHorizontal: size.size_4
    },
    button: {
        marginHorizontal: 0,
        marginTop: 0
    }
});

function mapStateToProps(state) {
    return {
        classData: state.classReducer,
        subjectData: state.subjectReducer,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        classActions: bindActionCreators(actions, dispatch),
        subjectActions: bindActionCreators(subjectActions, dispatch),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(AddExamDetail);