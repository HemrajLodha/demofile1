import React from "react";
import {Alert, Animated, StyleSheet, Text, View} from "react-native";
import {ListItem} from "react-native-elements";
import color from "../../../../assets/values/color";
import size, {actual_height, isIOS} from "../../../../assets/values/dimens";
import font from "../../../../assets/values/font";
import Strings from "../../../../assets/strings/strings";
import * as actions from "../../../reducers/addMarks/actions";
import {bindActionCreators} from "redux";
import {connect} from "react-redux";
import {BaseScrollView, DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import {Utils} from "../../../utils/Utils";
import ProgressView from "../../../widget/ProgressView";
import StudentMarkItem from "./item/StudentMarkItem";
import ErrorView from "../../../widget/ErrorView";
import Moment from "moment/moment";
import {validateMarks} from "../../../utils/ValidateUtils";
import {SortType} from "../../../model/SortType";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";

class AddExamMarks extends React.Component {

    constructor(props) {
        super(props);

        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                return 0;
            },
            (type, dim) => {
                dim.width = size.screen_width;
                dim.height = size.screen_width / 4;
            }
        );

        this.scroll = new Animated.Value(0);
        this.scroll.addListener((value) => {
            console.log(value);
        });

        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));

    }

    onNavigatorEvent(event) {
        if (event.type == 'NavBarButtonPress') {
            if (event.id == 'submit') {
                this.submitMarks(this.props);
            }
        }
    }

    componentWillUnmount() {
        this.props.studentActions.reset();
    }

    componentDidMount() {
        this.getStudentList(this.props);
    }

    componentDidUpdate(prevProps, prevState) {
        let {studentData, navigator} = this.props;
        let prevStudentData = prevProps.studentData;

        if (studentData.isLoaded != prevStudentData.isLoaded || studentData.isAdding != prevStudentData.isAdding) {
            this.showSubmitButton(!studentData.isLoaded, studentData.isAdding)
        }
        if (studentData.isAddedMessage != prevStudentData.isAddedMessage) {
            studentData.isAddedMessage && Alert.alert(Strings.app_name, studentData.isAddedMessage,
                [
                    {
                        text: 'OK', onPress: studentData.isAdded ? () => navigator.popToRoot() : undefined
                    },
                ],
                {cancelable: false});
        }
    }

    render() {
        let {studentData, classOption, subjectOption, testName, testDate, maxMarks} = this.props;

        return (
            <React.Fragment>
                <ListItem
                    containerStyle={styles.listContainer}
                    bottomDivider
                    topDivider
                    title={<View style={styles.contentContainer}>
                        <Text style={styles.title}>
                            {Strings.title_class}
                            {" - "}
                        </Text>
                        <Text style={styles.subtitle}>
                            {classOption.title}
                        </Text>
                    </View>}
                    subtitle={<View>
                        <View style={styles.contentContainer}>
                            <Text style={styles.title}>
                                {Strings.title_subject}
                                {" - "}
                            </Text>
                            <Text style={styles.subtitle}>
                                {subjectOption.name}
                            </Text>
                        </View>
                        <View style={styles.contentContainer}>
                            <Text style={styles.title}>
                                {Strings.test_name}
                                {" - "}
                            </Text>
                            <Text style={styles.subtitle}>
                                {testName}
                            </Text>
                        </View>
                        <View style={styles.contentContainer}>
                            <Text style={styles.title}>
                                {Strings.max_marks}
                                {" - "}
                            </Text>
                            <Text style={styles.subtitle}>
                                {maxMarks}
                            </Text>
                        </View>

                        <Text style={[styles.title, {color: color.error}]}>
                            {Strings.absent_warning}
                        </Text>
                    </View>}
                    rightIcon={!studentData.isLoaded ? undefined : {
                        containerStyle: styles.sortContainer,
                        name: 'sort',
                        color: color.white,
                        size: size.text_size_x_large,
                        underlayColor: color.transparent,
                        onPress: this.goToFilterStudent.bind(this)
                    }}
                />
                {
                    studentData.isLoading ? <ProgressView/> :
                        studentData.message ? <ErrorView error={studentData.message}/> :
                            Utils.isEmpty(studentData.data) ? <ErrorView error={Strings.no_student_found}/> :
                                <RecyclerListView
                                    style={styles.list}
                                    bounces={false}
                                    layoutProvider={this.layoutProvider}
                                    dataProvider={this.dataProvider.cloneWithRows(studentData.data)}
                                    rowRenderer={this.rowRenderer.bind(this, studentData.url)}
                                    externalScrollView={ExtendedScrollView}
                                    animatedEvent={{nativeEvent: {contentOffset: {y: this.scroll, x: 0,}}}}
                                />
                }
            </React.Fragment>
        );
    }

    rowRenderer = (url, type, data, index) => {
        return (
            <StudentMarkItem data={data}
                             url={url}
                             index={index}
                             onChangeMarks={this.onChangeMarks}/>
        )
    };

    getStudentList = ({classOption, subjectOption}) => {
        let params = {
            class_id: classOption.class_id
        };
        this.props.studentActions.getStudentData(params, subjectOption.id);
    };

    submitMarks = ({user, classOption, subjectOption, testName, testDate, maxMarks, studentData}) => {
        let params = {
            class_id: classOption.class_id,
            subject_id: subjectOption.id,
            user_id: user.user_id,
            user_member_id: user.id,
            title: testName,
            exam_date: Moment(testDate).format('YYYY-MM-DD'),
            max_marks: maxMarks,
            students_marks: JSON.stringify(studentData.data),
        };
        this.props.studentActions.submitStudentMarks(params, studentData.data);
    };

    onChangeMarks = (data, index) => {
        let students = this.props.studentData.data;
        let maxMarks = this.props.maxMarks;
        let error = validateMarks(data.marks, maxMarks);
        students[index] = {...data, error};
        this.props.studentActions.changeMarks(students);
    };

    onPressFilter = (sort_type) => {
        this.props.studentActions.filterData(sort_type)
    };

    showSubmitButton = (disabled, showProgress) => {
        this.props.navigator.setButtons({
            rightButtons: [showProgress ? {
                    component: 'nactus.ProgressView',
                    passProps: {
                        style: styles.loading,
                        size: "small",
                        color: color.white,
                    },
                    disabled: true
                } :
                {
                    id: 'submit',
                    title: Strings.submit,
                    disabled: disabled
                }
            ]
        })
    };

    goToFilterStudent = () => {
        this.props.navigator.showLightBox({
            screen: 'nactus.SelectorDialog',
            passProps: {
                title: Strings.sort_students,
                data: [
                    {title: Strings.by_name, type: SortType.TYPE_NAME},
                    {title: Strings.by_enrollment_number, type: SortType.TYPE_EN}
                ],
                onPress: this.onPressFilter.bind(this)
            },
            style: {
                backgroundBlur: 'dark', // 'dark' / 'light' / 'xlight' / 'none' - the type of blur on the background
                backgroundColor: color.light_box_bg, // tint color for the background, you can specify alpha here (optional)
                tapBackgroundToDismiss: true // dismisses LightBox on background taps (optional)
            }
        })
    };

}

class ExtendedScrollView extends BaseScrollView {
    render() {
        let {animatedEvent, onScroll} = this.props;
        return (
            <KeyboardAwareScrollView
                {...this.props}
                bounces={false}
                onScroll={Animated.event([animatedEvent], {
                    listener: onScroll,
                })}/>
        );
    }

    scrollTo(...args) {
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    list: {
        flex: 1,
        width: size.screen_width,
        height: actual_height
    },
    listContainer: {
        backgroundColor: color.transparent,
    },
    contentContainer: {
        flexDirection: 'row'
    },
    title: {
        color: color.white,
        fontFamily: font.bold,
        fontSize: size.text_size_small
    },
    subtitle: {
        color: color.white,
        fontFamily: font.regular,
        fontSize: size.text_size_small
    },
    loading: {
        width: size.toolbar_height,
        backgroundColor: color.colorPrimary
    },
    sortContainer: {
        position: 'absolute',
        right: size.size_16,
        bottom: size.size_16
    }
});


function mapStateToProps(state) {
    return {
        studentData: state.addMarksReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        studentActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(AddExamMarks);