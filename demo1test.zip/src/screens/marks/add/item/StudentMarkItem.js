import React from "react";
import Strings from "../../../../../assets/strings/strings";
import color from "../../../../../assets/values/color";
import FastImage from "react-native-fast-image";
import size from "../../../../../assets/values/dimens";
import {StyleSheet, Text, View} from "react-native";
import font from "../../../../../assets/values/font";
import {Avatar, ListItem} from "react-native-elements";
import InputView from "../../../../widget/InputView";
import {Utils} from "../../../../utils/Utils";

class StudentMarkItem extends React.Component {

    render() {
        let {url, data, onChangeMarks, index} = this.props;
        return (
            <ListItem containerStyle={styles.container}
                      contentContainerStyle={styles.contentContainer}
                      bottomDivider
                      title={data.first_name}
                      titleStyle={styles.title}
                      subtitle={<View>
                          <Text style={[styles.subtitle, {color: color.white}]}>{"E.N. - " + data.enroll_id}</Text>
                          <Text style={styles.subtitle}>{data.error}</Text>
                      </View>}
                      leftAvatar={Utils.isEmpty(data.image) ?
                          <Avatar
                              overlayContainerStyle={{backgroundColor: color.transparent}}
                              containerStyle={styles.image}
                              rounded
                              titleStyle={styles.iconTitle}
                              title={data.first_name.substring(0, 1).toUpperCase()}
                          /> : <FastImage
                              style={styles.image}
                              source={{
                                  uri: Utils.getImageUrl(url, data.student_id, data.image),
                                  priority: FastImage.priority.normal,
                              }}
                              resizeMode={FastImage.resizeMode.cover}/>}
                      rightElement={<InputView
                          container={styles.containerMarks}
                          inputContainer={styles.inputContainerMarks}
                          placeholder={Strings.enter_marks}
                          placeholderTextColor={color.gray_400}
                          returnKeyType={'done'}
                          underline={false}
                          isLabel={false}
                          value={data.marks}
                          onChangeValue={text => {
                              data.marks = text;
                              onChangeMarks(data, index);
                          }}
                      />}
            />
        );
    }
}

const styles = StyleSheet.create({
    container: {
        height: '100%',
        backgroundColor: color.transparent,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5
    },
    contentContainer: {},
    title: {
        color: color.white,
        fontFamily: font.semibold,
        fontSize: size.text_size_small
    },
    subtitle: {
        color: color.error,
        fontFamily: font.semibold,
        fontSize: size.text_size_vv_small
    },
    image: {
        width: size.size_48,
        height: size.size_48,
        borderRadius: size.size_48 / 2,
        backgroundColor: color.light_box_bg,
        borderColor: color.gray_200,
        borderWidth: size.size_1
    },
    containerMarks: {
        width: '25%',
        marginTop: size.size_0,
        alignSelf: 'flex-end'
    },
    inputContainerMarks: {
        height: size.size_32,
        marginHorizontal: size.size_4
    },
});

export default StudentMarkItem;