import React from "react";
import {StyleSheet, TouchableOpacity} from "react-native";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/class/actions";
import {connect} from "react-redux";
import Strings from "../../../../assets/strings/strings";
import {Utils} from "../../../utils/Utils";
import {MenuProvider} from "react-native-popup-menu";
import PopupMenu from "../../../widget/PopupMenu";
import SearchView from "../../../widget/SearchView";
import size from "../../../../assets/values/dimens";
import * as subjectActions from "../../../reducers/subject/actions";
import * as studentActions from "../../../reducers/student/actions";
import * as marksActions from "../../../reducers/viewMarks/actions";
import color from "../../../../assets/values/color";
import StudentMarksChart from "./chart/StudentMarksChart";
import {DataProvider, LayoutProvider, RecyclerListView} from "recyclerlistview";
import ProgressView from "../../../widget/ProgressView";
import ErrorView from "../../../widget/ErrorView";
import StudentMarksItem from "./item/StudentMarksItem";

const TYPES = {
    CHART: 0,
    ITEM: 1
};

class ViewMarks extends React.Component {

    constructor(props) {
        super(props);

        this.line = require('../../../../assets/images/ic_graph_line.png');
        this.bar = require('../../../../assets/images/ic_graph_bar.png');

        this.dataProvider = new DataProvider((r1, r2) => {
            return r1 !== r2;
        });

        this.layoutProvider = new LayoutProvider(
            index => {
                switch (index) {
                    case 0:
                        return TYPES.CHART;
                    default:
                        return TYPES.ITEM;
                }

            },
            (type, dim) => {
                dim.width = size.screen_width;
                switch (type) {
                    case TYPES.CHART:
                        dim.height = size.screen_width * 0.8;
                        break;
                    case TYPES.ITEM:
                        dim.height = size.screen_width / 2.5;
                        break
                }
            }
        );

        this.state = {
            classOption: undefined,
            subjectOption: undefined,
            studentOption: undefined,
        };

        this.props.navigator.setOnNavigatorEvent(this.onNavigatorEvent.bind(this));

    }

    onNavigatorEvent(event) {
        if (event.type == 'NavBarButtonPress') {
            if (event.id == 'graph') {
                this.onChangeGraph(this.props);
            }
        }
    }


    componentDidMount() {
        this.getClassList(this.props);
    }

    componentWillUnmount() {
        this.props.classActions.reset();
        this.props.subjectActions.reset();
        this.props.studentActions.reset();
        this.props.marksActions.reset();
    }

    componentDidUpdate(prevProps, prevState) {
        let {marksData} = this.props;
        let prevMarksData = prevProps.marksData;
        let {classOption, subjectOption, studentOption} = this.state;
        let prevClassOption = prevState.classOption;
        let prevSubjectOption = prevState.subjectOption;
        let prevStudentOption = prevState.studentOption;
        if (classOption !== prevClassOption) {
            this.setState({
                subjectOption: undefined,
                studentOption: undefined,
            }, () => {
                if (classOption && classOption.is_mark) {
                    this.getSubjectList(classOption);
                    this.getStudentList(classOption);
                }
            });
        }

        if (classOption !== prevClassOption || subjectOption !== prevSubjectOption || studentOption !== prevStudentOption) {
            this.getStudentMarksData(this.state);
        }

        if (marksData.isLoaded != prevMarksData.isLoaded || marksData.isBarChart != prevMarksData.isBarChart) {
            this.showChartButton(!marksData.isLoaded, marksData.isBarChart);
        }
    }


    render() {
        let {classData, subjectData, studentData, marksData} = this.props;
        let {classOption, subjectOption, studentOption} = this.state;

        return (
            <MenuProvider style={styles.container}>
                <PopupMenu
                    placeHolder={{title: Strings.select_class, class_id: "-1"}}
                    options={classData.data}
                    loading={classData.isLoading}
                    disabled={Utils.isEmpty(classData.data)}
                    selectedKey={'class_id'}
                    selectedTitle={'title'}
                    selected={classOption ? classOption.class_id : undefined}
                    onSelect={this.doFilterClass}/>

                <PopupMenu
                    placeHolder={{name: Strings.select_subject, id: "-1"}}
                    options={subjectData.data}
                    loading={subjectData.isLoading}
                    disabled={classOption && !classOption.is_mark || Utils.isEmpty(subjectData.data)}
                    selectedKey={'id'}
                    selectedTitle={'name'}
                    selected={subjectOption ? subjectOption.id : undefined}
                    onSelect={this.doFilterSubject}/>

                <TouchableOpacity style={styles.searchContainer}
                                  onPress={this.onStudentPress.bind(this, studentData.data)}
                                  disabled={classOption && !classOption.is_mark || Utils.isEmpty(studentData.data)}>
                    <SearchView
                        pointerEvents="none"
                        ref={ref => this.searchBar = ref}
                        container={styles.containerSearch}
                        inputContainer={styles.inputContainerSearch}
                        placeholder={Strings.student_name}
                        value={studentOption ? studentOption.first_name : undefined}
                        editable={false}
                    />
                </TouchableOpacity>
                {
                    classOption && <React.Fragment>
                        {
                            classOption.is_mark ? marksData.isLoading ? <ProgressView/> :
                                Utils.isEmpty(marksData.data) ?
                                    marksData.message ?
                                        <ErrorView error={marksData.message}/> : null
                                    : <RecyclerListView
                                        style={styles.list}
                                        layoutProvider={this.layoutProvider}
                                        dataProvider={this.dataProvider.cloneWithRows(marksData.data)}
                                        rowRenderer={this.rowRenderer}
                                        forceNonDeterministicRendering={true}/> :
                                <ErrorView error={Strings.permission_view_marks}/>
                        }
                    </React.Fragment>
                }
            </MenuProvider>
        );
    }

    rowRenderer = (type, data, index) => {
        switch (type) {
            case TYPES.CHART:
                return (
                    <StudentMarksChart data={data.data}
                                       isBarChart={data.isBarChart}
                                       index={index}/>
                );
            case TYPES.ITEM:
                return (
                    <StudentMarksItem data={data}
                                      index={index}
                                      onPress={!data.isOpened ? this.onPressMarksItem.bind(this, index) : undefined}/>
                );
        }
    };

    onPressMarksItem = (position) => {
        this.props.marksActions.changePosition(position);
    };

    onChangeGraph = ({marksData}) => {
        this.props.marksActions.changeGraph(marksData.isBarChart);
    };

    getClassList = ({user}) => {
        let params = {
            user_member_id: user.id,
            status: 2
        };
        this.props.classActions.getClassData(params);
    };

    getSubjectList = (classOption) => {
        if (classOption) {
            let params = {
                class_id: classOption.class_id
            };
            this.props.subjectActions.getSubjectData(params);
        }
        else {
            this.props.subjectActions.reset();
        }
    };

    getStudentList = (classOption) => {
        if (classOption) {
            let params = {
                class_id: classOption.class_id
            };
            this.props.studentActions.getStudentData(params);
        }
        else {
            this.props.studentActions.reset();
        }
    };

    getStudentMarksData = ({classOption, subjectOption, studentOption}) => {
        if (classOption && subjectOption && studentOption) {
            let params = {
                class_id: classOption.class_id,
                subject_id: subjectOption.id,
                student_id: studentOption.student_id
            };
            this.props.marksActions.getStudentMarks(params);
        }
        else {
            this.props.marksActions.reset();
        }
    };

    doFilterClass = (option) => {
        this.setState({
            classOption: option
        })
    };

    doFilterSubject = (option) => {
        this.setState({
            subjectOption: option
        })
    };

    onSearchStudent = (student) => {
        this.setState({
            studentOption: student
        });
    };

    onStudentPress = (students) => {
        this.props.navigator.showLightBox({
            screen: 'nactus.SearchStudent',
            passProps: {
                students: students,
                onSearch: this.onSearchStudent
            },
            style: {
                backgroundBlur: 'dark', // 'dark' / 'light' / 'xlight' / 'none' - the type of blur on the background
                backgroundColor: color.light_box_bg, // tint color for the background, you can specify alpha here (optional)
                tapBackgroundToDismiss: true // dismisses LightBox on background taps (optional)
            }
        })
    };

    showChartButton = (disabled, isBarChart) => {
        this.props.navigator.setButtons({
            rightButtons: [{
                id: 'graph',
                icon: isBarChart ? this.line : this.bar,
                disabled: disabled
            }]
        })
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    searchContainer: {
        flexDirection: 'row'
    },
    containerSearch: {
        marginTop: size.size_4,
    },
    inputContainerSearch: {
        marginHorizontal: size.size_4
    },
    list: {
        flex: 1,
    },
});

function mapStateToProps(state) {
    return {
        classData: state.classReducer,
        subjectData: state.subjectReducer,
        studentData: state.studentReducer,
        marksData: state.viewMarksReducer,
    }
}

function mapDispatchToProps(dispatch) {
    return {
        classActions: bindActionCreators(actions, dispatch),
        subjectActions: bindActionCreators(subjectActions, dispatch),
        studentActions: bindActionCreators(studentActions, dispatch),
        marksActions: bindActionCreators(marksActions, dispatch),
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(ViewMarks);