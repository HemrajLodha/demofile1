import React from 'react';
import {processColor, StyleSheet, View, Alert} from 'react-native';

import {BarChart, LineChart} from 'react-native-charts-wrapper';
import size, {isMobile} from "../../../../../assets/values/dimens";
import color from "../../../../../assets/values/color";
import Strings from "../../../../../assets/strings/strings";
import {DataProvider, LayoutProvider} from "recyclerlistview";
import {Utils} from "../../../../utils/Utils";

class StudentMarksChart extends React.Component {

    constructor() {
        super();
        this.state = {
            data: undefined,
            valueFormatter: [],
            isBarChart: undefined,
            axisMaximum: 0
        };
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let {data, isBarChart} = nextProps;
        let maxObtainedMarks = [];
        let avgObtainedMarks = [];
        let studentObtainedMarks = [];
        let valueFormatter = [];
        data.forEach((item, index) => {
            let maxMarks = parseFloat(item.max_marks);
            item.student_mark = !Utils.isNull(item.student_mark) ? item.student_mark : '0';
            let studentMark = item.student_mark.toLowerCase() == 'a' ? 0 : item.student_mark;
            maxObtainedMarks[index] = (parseFloat(item.max_obtained_marks) / maxMarks) * 100;
            avgObtainedMarks[index] = (parseFloat(item.avg_marks) / maxMarks) * 100;
            studentObtainedMarks[index] = (parseFloat(studentMark) / maxMarks) * 100;
            valueFormatter[index] = item.exam_short_title;
        });

        let nextState = Utils.isEmpty(data) ? null : {
            data: {
                dataSets: [
                    {
                        values: maxObtainedMarks,
                        label: Strings.max_obt_marks,
                        config: {
                            ...chart.dataSetsConfig,
                            colors: [processColor(color.green)],
                        }
                    },
                    {
                        values: avgObtainedMarks,
                        label: Strings.avg_obt_marks,
                        config: {
                            ...chart.dataSetsConfig,
                            colors: [processColor(color.gray_500)],
                        }
                    },
                    {
                        values: studentObtainedMarks,
                        label: Strings.student_score,
                        config: {
                            ...chart.dataSetsConfig,
                            colors: [processColor(color.colorPrimaryDark)],
                        }
                    }
                ],
                config: chart.dataConfig
            },
            valueFormatter: valueFormatter,
            isBarChart: isBarChart,
            axisMaximum: data.length
        };
        return nextState;
    }

    render() {
        let {data, valueFormatter, axisMaximum, isBarChart} = this.state;
        return (
            <View style={styles.container}>
                {
                    data && isBarChart ? <BarChart
                            style={styles.chart}
                            xAxis={{...chart.xAxis, valueFormatter, axisMaximum}}
                            yAxis={chart.yAxis}
                            legend={chart.legend}
                            data={data}
                            drawValueAboveBar={false}
                        /> :
                        <LineChart
                            style={styles.chart}
                            xAxis={{...chart.xAxis, valueFormatter}}
                            yAxis={chart.yAxis}
                            legend={chart.legend}
                            data={data}
                            drawValueAboveBar={false}
                        />
                }
            </View>

        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: color.white,
        marginVertical: size.size_8,
        marginHorizontal: size.size_4,
        paddingVertical: size.size_16
    },
    chart: {
        width: size.screen_width,
        height: size.screen_width * 0.8
    },
});

const chart = {
    legend: {
        enabled: true,
        textSize: size.text_size_x_small,
        form: "SQUARE",
        formSize: size.text_size_x_small,
        wordWrapEnabled: true,
        yEntrySpace: size.size_4,
        xEntrySpace: size.size_12,
    },
    xAxis: {
        granularityEnabled: true,
        granularity: 1,
        axisMinimum: 0,
        centerAxisLabels: true
    },
    yAxis: {
        left: {
            axisMaximum: 100,
            axisMinimum: 0,
        },
        right: {
            axisMaximum: 100,
            axisMinimum: 0,
        }
    },
    dataConfig: {
        barWidth: 0.2,
        group: {
            fromX: 0,
            groupSpace: 0.1,
            barSpace: 0.1,
        }
    },
    dataSetsConfig: {
        valueTextSize: isMobile ? 6 : 12,
        valueFormatter: 'percent',
    }
};


export default StudentMarksChart;