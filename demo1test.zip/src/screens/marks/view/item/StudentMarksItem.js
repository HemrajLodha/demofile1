import React from "react";
import {Card, Icon, ListItem} from "react-native-elements";
import size from "../../../../../assets/values/dimens";
import {StyleSheet, Text, View} from "react-native";
import font from "../../../../../assets/values/font";
import color from "../../../../../assets/values/color";
import Strings from "../../../../../assets/strings/strings";
import {Utils} from "../../../../utils/Utils";

class MarksItem extends React.Component {
    render() {
        let {itemColor = color.gray_700, title, subtitle} = this.props;
        return (
            <View style={styles.itemContainer}>
                <Text style={[styles.itemText, {color: itemColor, fontFamily: font.semibold}]}>
                    {title}
                    {" : "}
                </Text>
                <Text style={[styles.itemText, {color: itemColor, fontFamily: font.regular}]}>
                    {subtitle}
                </Text>
            </View>
        );
    }
}


class StudentMarksItem extends React.Component {

    render() {
        let {data, onPress} = this.props;
        data.student_mark = !Utils.isNull(data.student_mark) ? data.student_mark : '0';
        return (
            <Card containerStyle={styles.container}>
                <ListItem containerStyle={styles.listContainer}
                          title={data.exam_long_title}
                          titleStyle={styles.title}
                          subtitle={
                              <View style={styles.listWrapper}>
                                  <MarksItem title={Strings.test_date} subtitle={data.exam_date}/>
                                  {
                                      data.isOpened && <React.Fragment>
                                          <View style={styles.itemWrapper}>
                                              <MarksItem title={Strings.max_marks}
                                                         subtitle={parseFloat(data.max_marks)}/>
                                              <MarksItem title={Strings.scored_marks}
                                                         subtitle={data.student_mark.toLowerCase() == 'a' ? data.student_mark : parseFloat(data.student_mark)}
                                                         itemColor={color.error}/>
                                          </View>
                                          <View style={styles.itemWrapper}>
                                              <MarksItem title={Strings.highest_marks}
                                                         subtitle={parseFloat(data.max_obtained_marks)}
                                                         itemColor={color.green}/>
                                              <MarksItem title={Strings.avg_marks} subtitle={parseFloat(data.avg_marks)}
                                                         itemColor={color.orange_light}/>
                                          </View>
                                          <View style={styles.itemWrapper}>
                                              <MarksItem title={Strings.total_student}
                                                         subtitle={parseInt(data.total_student)}/>
                                              <MarksItem title={Strings.rank} subtitle={data.rank}
                                                         itemColor={color.colorPrimary}/>
                                          </View>
                                      </React.Fragment>
                                  }
                              </View>
                          }
                          rightElement={
                              <Icon
                                  containerStyle={styles.icon}
                                  name={data.isOpened ? 'remove' : 'add'}
                                  onPress={onPress}/>
                          }
                />
            </Card>
        );
    }

}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        margin: size.size_4,
        padding: 0
    },
    listContainer: {
        paddingRight: 0,
        marginRight: 0
    },
    listWrapper: {
        marginTop: size.size_4
    },
    itemWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: size.size_2
    },
    title: {
        color: color.gray_900,
        fontSize: size.text_size_v_medium,
        fontFamily: font.semibold
    },
    itemContainer: {
        flexDirection: 'row'
    },
    itemText: {
        fontSize: size.text_size_small,
        fontFamily: font.semibold,
        color: color.gray_700
    },
    icon: {
        position: 'absolute',
        top: size.size_12,
        right: size.size_12
    }
});

export default StudentMarksItem;