import React from "react";
import {Text, View} from "react-native";
import styles from "./styles";
import {ListItem} from "react-native-elements";
import Strings from "../../../assets/strings/strings";
import color from "../../../assets/values/color";
import EditPasswordSettings from "./edit/EditPasswordSettings";
import {disclaimer_base_url} from "../../api/api";
import {Utils} from "../../utils/Utils";


class Settings extends React.Component {
    render() {
        let {user} = this.props;
        return (
            <View style={styles.container}>
                <ListItem
                    containerStyle={styles.listContainer}
                    chevronColor={color.white}
                    chevron
                    bottomDivider
                    title={Strings.change_password}
                    titleStyle={styles.title}
                    onPress={() => this.goToChangePassword(user)}
                />
                <ListItem
                    containerStyle={styles.listContainer}
                    chevronColor={color.white}
                    chevron
                    bottomDivider
                    title={Strings.disclaimer}
                    titleStyle={styles.title}
                    onPress={() => this.goToWebView(Strings.disclaimer, disclaimer_base_url)}
                />
                <ListItem
                    containerStyle={styles.listContainer}
                    bottomDivider
                    title={Strings.version}
                    titleStyle={styles.title}
                    rightElement={<Text style={styles.title}>
                        {
                            "1.0.0"
                        }
                    </Text>}
                />
            </View>
        );
    }

    goToChangePassword = (user) => {
        this.props.navigator.push({
            screen: 'nactus.EditPasswordSettings',
            title: Strings.change_password,
            passProps: {
                user: user
            }
        })
    };

    goToWebView = (title, url) => {
        this.props.navigator.push({
            screen: 'nactus.NactusWebView',
            title: title,
            passProps: {
                url: url
            }
        })
    };
}

export default Settings;