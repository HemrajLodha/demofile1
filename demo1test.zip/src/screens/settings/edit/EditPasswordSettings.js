import React from "react";
import {Alert, StyleSheet} from "react-native";
import ButtonView from "../../../widget/ButtonView";
import {validate, validatePassword} from "../../../utils/ValidateUtils";
import {KeyboardAwareScrollView} from "react-native-keyboard-aware-scroll-view";
import InputView from "../../../widget/InputView";
import {bindActionCreators} from "redux";
import * as actions from "../../../reducers/editPassword/actions";
import {connect} from "react-redux";
import Strings from "../../../../assets/strings/strings";


class EditPasswordSettings extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            oldPasswordError: undefined,
            oldPassword: undefined,
            newPasswordError: undefined,
            newPassword: undefined,
            confirmPasswordError: undefined,
            confirmPassword: undefined,
        };
    }

    componentWillUnmount() {
        this.props.editPasswordActions.reset();
    }

    componentDidUpdate(prevProps) {
        let {editPasswordData, navigator} = this.props;
        let prevEditPasswordData = prevProps.editPasswordData;
        if (editPasswordData !== prevEditPasswordData) {
            editPasswordData.message && Alert.alert(Strings.app_name, editPasswordData.message,
                [
                    {text: Strings.OK, onPress: editPasswordData.isUpdated ? () => navigator.pop() : undefined}
                ],
                {cancelable: !editPasswordData.isUpdated});
        }
    }

    render() {
        let {editPasswordData, user} = this.props;
        let {oldPasswordError, newPasswordError, confirmPasswordError} = this.state;

        return (
            <KeyboardAwareScrollView>
                <InputView
                    ref={ref => this.oldPassword = ref}
                    iconName={'lock-outline'}
                    iconType={'material-community'}
                    placeholder={Strings.old_password}
                    showPassword={true}
                    editable={!editPasswordData.isUpdating}
                    errorMessage={oldPasswordError}
                    onChangeValue={text => this.setState({oldPassword: text})}
                    onSubmitEditing={(event) => {
                        this.newPassword.focus();
                    }}
                />

                <InputView
                    ref={ref => this.newPassword = ref}
                    iconName={'lock-outline'}
                    iconType={'material-community'}
                    placeholder={Strings.new_password}
                    showPassword={true}
                    editable={!editPasswordData.isUpdating}
                    errorMessage={newPasswordError}
                    onChangeValue={text => this.setState({newPassword: text})}
                    onSubmitEditing={(event) => {
                        this.confirmPassword.focus();
                    }}
                />

                <InputView
                    ref={ref => this.confirmPassword = ref}
                    iconName={'lock-outline'}
                    iconType={'material-community'}
                    placeholder={Strings.confirm_password}
                    showPassword={true}
                    editable={!editPasswordData.isUpdating}
                    errorMessage={confirmPasswordError}
                    returnKeyType={'done'}
                    onChangeValue={text => this.setState({confirmPassword: text})}
                />

                <ButtonView
                    title={Strings.title_update}
                    loading={editPasswordData.isUpdating}
                    onPress={() => this.doUpdatePassword(this.state, user)}/>
            </KeyboardAwareScrollView>
        );
    }

    doUpdatePassword = ({oldPassword, newPassword, confirmPassword}, user) => {
        let oldPasswordError = validate('oldPassword', oldPassword);
        let newPasswordError = validate('newPassword', newPassword);
        let confirmPasswordError = validatePassword('confirmPassword', newPassword, confirmPassword);
        this.setState({
            oldPasswordError: oldPasswordError,
            newPasswordError: newPasswordError,
            confirmPasswordError: confirmPasswordError,
        }, () => {
            if (!oldPasswordError && !newPasswordError && !confirmPasswordError) {
                let params = {
                    faculty_id: user.id,
                    old_password: oldPassword,
                    new_password: newPassword,
                    confirm_password: confirmPassword,
                };

                this.props.editPasswordActions.doChangePasswordRequest(params);
            }
        });


    };

}

const styles = StyleSheet.create({});


function mapStateToProps(state) {
    return {
        editPasswordData: state.editPasswordReducer
    }
}

function mapDispatchToProps(dispatch) {
    return {
        editPasswordActions: bindActionCreators(actions, dispatch)
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(EditPasswordSettings);