import {StyleSheet} from "react-native";
import color from "../../../assets/values/color";
import size from "../../../assets/values/dimens";
import font from "../../../assets/values/font";

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    listContainer: {
        backgroundColor: color.transparent,
    },
    title: {
        color: color.white,
        fontFamily: font.semibold,
        fontSize: size.text_size_small
    }
});

export default styles;