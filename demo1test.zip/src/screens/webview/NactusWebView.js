import React from "react";
import {WebView, StyleSheet} from "react-native";
import color from "../../../assets/values/color";


class NactusWebView extends React.Component {

    render() {
        let {url} = this.props;
        return (
            <WebView
                automaticallyAdjustContentInsets={false}
                style={styles.webView}
                source={{uri: url}}
                javaScriptEnabledAndroid={true}
                onNavigationStateChange={this.onNavigationStateChange}
                onShouldStartLoadWithRequest={this.onShouldStartLoadWithRequest}
                startInLoadingState={true}
                scalesPageToFit={true}
            />
        );
    }

    onNavigationStateChange = (navState) => {

    };

    onShouldStartLoadWithRequest = (event) => {
        // Implement any custom loading logic here, don't forget to return!
        return true;
    }
}

const styles = StyleSheet.create({
    webView: {
        backgroundColor: color.white,
        height: 350,
    }
});

export default NactusWebView;