import {AsyncStorage} from "react-native";

const UserStore = 'user';
const TokenStore = 'token';

export function setUserSessionData(user, token) {
    let pair = [
        [UserStore, JSON.stringify(user)],
        [TokenStore, JSON.stringify(token)]
    ];
    return new Promise((resolve, reject) =>
        AsyncStorage.multiSet(pair)
            .then(resolve)
            .catch(reject));
}


export function setTokenData(token) {
    return new Promise((resolve, reject) =>
        AsyncStorage.setItem(TokenStore, JSON.stringify(token))
            .then(resolve)
            .catch(reject));
}

export function setUserData(user) {
    return new Promise((resolve, reject) =>
        AsyncStorage.setItem(UserStore, JSON.stringify(user))
            .then(resolve)
            .catch(reject));
}

export function getUserSessionData() {
    let pair = [
        UserStore, TokenStore
    ];
    return new Promise((resolve, reject) =>
        AsyncStorage.multiGet(pair)
            .then(resolve)
            .catch(reject));
}


export function getSessionData() {
    return new Promise((resolve, reject) => {
        AsyncStorage.getItem(TokenStore)
            .then(token => token ? resolve(JSON.parse(token)) : reject("failed to get token"))
            .catch(reject);
    });
}

export function getUserData() {
    return new Promise((resolve, reject) => {
        AsyncStorage.getItem(UserStore)
            .then(user => user ? resolve(JSON.parse(user)) : reject("failed to get user"))
            .catch(reject);
    });
}

export function getUserId() {
    return new Promise((resolve, reject) => {
        getUserData().then(user => {
            if (user) {
                resolve(user.id);
            } else {
                reject("failed to get user id");
            }
        }).catch(err => {
            reject(err);
        })
    })
}

export function logout() {
    return new Promise((resolve, reject) => {
        AsyncStorage.clear(error => {
            if (error) {
                reject(error);
            } else {
                resolve();
            }
        });
    })
}