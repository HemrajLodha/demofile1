import {NetInfo, Platform} from "react-native";

export default class NetworkUtil {

    static async checkNetworkConnection() {
        if (Platform.OS === 'ios') {
            return new Promise((resolve, reject) => {
                const connectionHandler = connectionInfo => {
                    NetInfo.removeEventListener('connectionChange', connectionHandler);

                    resolve(connectionInfo);
                };

                NetInfo.addEventListener('connectionChange', connectionHandler);
            })
        }
        return NetInfo.getConnectionInfo();
    }

    static isConnected() {
        return new Promise((resolve, reject) => {
            NetInfo.isConnected.fetch().then(isConnected => {
                resolve(isConnected);
            }).catch(err => {
                reject(err);
            });

        });
    }

}