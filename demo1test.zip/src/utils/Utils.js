import Strings from "../../assets/strings/strings";
import {Platform} from "react-native";
import {isIOS} from "../../assets/values/dimens";

export class Utils {
    static isNull(data) {
        return data === 'null' || data === null || data === undefined || data === '';
    };

    static isEmpty(array) {
        return array === null || array === undefined || array.length === 0;
    };

    static getImageUrl(base_url, id, url) {
        return base_url + "/" + id + "/" + url;
    };

    static stripHtml(html) {
        try {
            let str = html.toString();
            str = str.replace(/<(?:.|\s)*?>|(?:&nbsp;)/g, "");
            return str || "";
        } catch (err) {
            console.log('err', err);
            return "";
        }
    };

    static stringReplace(template, values) {
        return template.replace(/%s/g, function () {
            return values.shift();
        });
    }

    static msword() {
        return isIOS ? "com.microsoft.word.doc" : "application/msword";
    }
}
