const validation = {
    email: {
        presence: {
            message: '^error_email'
        },
        format: {
            pattern: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            message: '^error_valid_email'
        }
    },
    userName: {
        presence: {
            message: '^error_userName'
        },
    },
    otp: {
        presence: {
            message: '^error_otp'
        },
    },
    emailMobile: {
        presence: {
            message: '^error_email_mobile'
        },
        format: {
            pattern: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$|^[0-9]{6,14}$/,
            message: '^error_valid_email_mobile'
        }
    },
    password: {
        presence: {
            message: '^error_password'
        },
        length: {
            minimum: 6,
            message: '^error_valid_password'
        }
    },
    oldPassword: {
        presence: {
            message: '^error_old_password'
        },
        length: {
            minimum: 6,
            message: '^error_valid_password'
        }
    },
    newPassword: {
        presence: {
            message: '^error_new_password'
        },
        length: {
            minimum: 6,
            message: '^error_valid_password'
        }
    },
    confirmPassword: {
        presence: {
            message: '^error_confirm_password'
        },
        length: {
            minimum: 6,
            message: '^error_valid_password'
        },
        equality: "newPassword"
    },
    mobile: {
        presence: {
            message: '^error_mobile'
        },
        format: {
            pattern: /^[0-9]{6,14}$/,
            message: '^error_valid_mobile'
        }
    },
    classOption: {
        presence: {
            message: '^error_classOption'
        },
    },
    subjectOption: {
        presence: {
            message: '^error_subjectOption'
        },
    },
    testName: {
        presence: {
            message: '^error_testName'
        },
    },
    testDate: {
        presence: {
            message: '^error_testDate'
        },
    },
    message: {
        presence: {
            message: '^error_message'
        },
    },
    caption: {
        presence: {
            message: '^error_caption'
        },
    },
    file: {
        presence: {
            message: '^error_file'
        },
    },
    maxMarks: {
        presence: {
            message: '^error_maxMarks'
        },
        format: {
            pattern: /^[0-9\b]+$/,
            message: '^error_valid_maxMarks'
        },
    },
    marks: {
        presence: {
            message: '^error_marks'
        },
        format: {
            pattern: /^[+-]?([0-9]*[.])?[0-9]+$|a$/i,
            message: '^error_valid_marks'
        }
    },
};

export default validation;