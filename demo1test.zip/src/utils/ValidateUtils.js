import validation from "./Validate";
import {Utils} from "./Utils";
import Strings from "../../assets/strings/strings";

var validateJS = require("validate.js");

export function validate(fieldName, value) {
    // Validate.js validates your values as an object
    // e.g. var form = {email: 'email@example.com'}
    // Line 8-9 creates an object based on the field name and field value
    let formValues = {};
    formValues[fieldName] = Utils.isNull(value) ? undefined : value;

    // Line 13-14 creates an temporary form with the validation fields
    // e.g. var formFields = {
    //                        email: {
    //                         presence: {
    //                          message: 'Email is blank'
    //                         }
    //                       }
    let formFields = {};
    formFields[fieldName] = validation[fieldName];


    // The formValues and validated against the formFields
    // the variable result hold the error messages of the field
    const result = validateJS(formValues, formFields)

    // If there is an error message, return it!
    if (result) {
        // Return only the field error message if there are multiple
        return Strings[result[fieldName][0]];
    }

    return null;
}

export function validatePassword(fieldName, value1, value2) {
// Validate.js validates your values as an object
    // e.g. var form = {email: 'email@example.com'}
    // Line 8-9 creates an object based on the field name and field value
    let formValues = {};
    formValues['newPassword'] = value1;
    formValues[fieldName] = value2;

    // Line 13-14 creates an temporary form with the validation fields
    // e.g. var formFields = {
    //                        email: {
    //                         presence: {
    //                          message: 'Email is blank'
    //                         }
    //                       }
    let formFields = {};
    formFields[fieldName] = validation[fieldName];


    // The formValues and validated against the formFields
    // the variable result hold the error messages of the field
    const result = validateJS(formValues, formFields);

    // If there is an error message, return it!
    if (result) {
        // Return only the field error message if there are multiple
        return Strings[result[fieldName][0]];
    }

    return null;
}

export function validateMarks(marks, maxMarks) {
    // Validate.js validates your values as an object
    // e.g. var form = {email: 'email@example.com'}
    // Line 8-9 creates an object based on the field name and field value
    let fieldName = 'marks';
    let formValues = {};
    formValues[fieldName] = Utils.isNull(marks) ? undefined : marks;

    // Line 13-14 creates an temporary form with the validation fields
    // e.g. var formFields = {
    //                        email: {
    //                         presence: {
    //                          message: 'Email is blank'
    //                         }
    //                       }
    let formFields = {};
    formFields[fieldName] = validation[fieldName];
    if (formValues[fieldName] && formValues[fieldName].toLowerCase() !== 'a') {
        let numericality = {
            message: '^error_right_marks',
            lessThanOrEqualTo: parseInt(maxMarks)
        };
        formFields[fieldName] = {...formFields[fieldName],numericality};
    }
    // The formValues and validated against the formFields
    // the variable result hold the error messages of the field
    const result = validateJS(formValues, formFields);

    // If there is an error message, return it!
    if (result) {
        // Return only the field error message if there are multiple
        return Strings[result[fieldName][0]];
    }

    return null;
}