import React from "react";
import {StyleSheet} from "react-native";
import {Button} from "react-native-elements";
import color from "../../assets/values/color";
import font from "../../assets/values/font";
import size from "../../assets/values/dimens";


class ButtonView extends React.Component {

    render() {
        let {style} = this.props;
        return (
            <Button
                containerStyle={[styles.container, style]}
                buttonStyle={styles.button}
                titleStyle={styles.title}
                {...this.props}/>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        marginTop: size.size_36,
        marginHorizontal: size.size_24
    },
    button: {
        height: size.buttonHeight,
        backgroundColor: color.colorPrimary,
        borderColor: color.transparent,
        borderWidth: 0,
        borderRadius: 0,
    },
    title: {
        fontSize: size.text_size_v_medium,
        fontFamily: font.bold,
        fontWeight: 'normal',
        color: color.white
    }
});

export default ButtonView