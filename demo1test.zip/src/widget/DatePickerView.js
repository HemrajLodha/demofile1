import React from "react";
import {Alert} from "react-native";
import InputView from "./InputView";
import size from "../../assets/values/dimens";
import SearchView from "./SearchView";
import {TouchableOpacity} from "react-native";
import {DatePickerDialog} from "react-native-datepicker-dialog";
import Moment from "moment";
import Strings from "../../assets/strings/strings";


class DatePickerView extends React.Component {

    constructor(props) {
        super();
        this.state = {
            date: undefined,
            maxDate: undefined,
            value: undefined,
            format: undefined
        }
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let {date, maxDate = new Date(), format = 'DD/MM/YYYY'} = nextProps;
        let nextState = (prevState.date == date) ? null : {
            date: date,
            value: Moment(date).format(format)
        };
        return nextState;
    }

    render() {
        let {disabled, onPick, maxDate = new Date(), format = 'DD/MM/YYYY'} = this.props;
        let {value, date} = this.state;
        return (
            <TouchableOpacity style={{width: '100%'}}
                              onPress={this.open.bind(this, date, maxDate)}
                              disabled={disabled}>
                <InputView
                    pointerEvents="none"
                    iconName={'calendar'}
                    iconType={'font-awesome'}
                    iconSize={size.text_size_small}
                    underline={false}
                    isLabel={false}
                    editable={false}
                    value={value}
                    {...this.props}/>
                {
                    <DatePickerDialog ref={ref => this.dialog = ref}
                                      onDatePicked={this.onDatePicked.bind(this, format, onPick)}/>
                }
            </TouchableOpacity>
        );
    }

    open = (date, maxDate) => {
        this.dialog.open({
            date: date,
            maxDate: maxDate //To restirct future date
        })
    };

    onDatePicked = (format, onPick, date) => {
        this.setState({
            date: date,
            value: Moment(date).format(format)
        }, onPick ? onPick.bind(this, date) : undefined)
    }
}

export default DatePickerView;