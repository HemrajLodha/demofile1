import React from "react";
import {StyleSheet, Text, View} from "react-native";
import PropTypes from "prop-types";
import size from "../../assets/values/dimens";
import font from "../../assets/values/font";
import color from "../../assets/values/color";


class ErrorView extends React.PureComponent {

    static propTypes = {
        error: PropTypes.string.isRequired,
    };

    render() {
        return (
            <View style={styles.container}>
                <Text style={styles.errorStyle}>{this.props.error}</Text>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: 'transparent',
        justifyContent: 'center',
        alignItems: 'center'
    },
    errorStyle: {
        textAlign: 'center',
        fontSize: size.text_size_small,
        fontFamily: font.semibold,
        color: color.white
    }
});

export default ErrorView;