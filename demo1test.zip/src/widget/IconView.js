import React from "react";
import {StyleSheet} from "react-native";
import {Icon} from "react-native-elements";
import color from "../../assets/values/color";

class IconView extends React.Component {

    render() {
        return (
            <Icon
                containerStyle={styles.icon}
                name={'close'}
                color={color.colorPrimary}
                {...this.props}>
            </Icon>
        );
    }
}

const styles = StyleSheet.create({
    icon: {
        position: 'absolute',
        right: 0
    }
});

export default IconView;
