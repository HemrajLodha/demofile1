import React from "react";
import {StyleSheet, Alert} from "react-native";
import {Icon, Input} from "react-native-elements";
import color from "../../assets/values/color";
import size from "../../assets/values/dimens";
import font from "../../assets/values/font";


class InputView extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            value: undefined,
            secureTextEntry: props.showPassword
        }
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let {value, showPassword} = nextProps;
        let nextState = (!value || prevState.value == value) ? null : {value: value};
        return nextState;
    }

    onChangeText = (onChangeValue, value) => {
        this.setState({
            value
        }, onChangeValue ? onChangeValue.bind(this, value) : undefined)
    };

    focus() {
        this.input.focus();
    }

    blur() {
        this.input.blur();
    }

    clearText() {
        this.input.clearText();
    }

    shake() {
        this.input.shake();
    }

    render() {
        let {
            container, inputContainer, iconName, label, iconColor, iconType, iconSize, errorMessage,
            placeholder, onChangeValue, themeColor = color.white, isLabel = true, isRight = false,
            underline = true, multiline = false, showPassword
        } = this.props;
        let {value, secureTextEntry} = this.state;
        iconColor = themeColor;
        return (
            <Input
                ref={input => this.input = input}
                containerStyle={[styles.container, container]}
                inputContainerStyle={[styles.inputContainer, inputContainer, underline ? [styles.underline, {borderBottomColor: themeColor}] : [styles.border, {borderColor: themeColor}]]}
                inputStyle={[styles.input, {color: themeColor}, multiline ? styles.multiline : {}]}
                labelStyle={[styles.label, {color: themeColor, marginLeft: iconName ? size.size_54 : 0}]}
                errorStyle={[styles.error, {marginLeft: iconName ? size.size_16 : size.size_16}]}
                underlineColorAndroid={color.transparent}
                placeholderTextColor={themeColor}
                shake={!!errorMessage}
                label={value && isLabel ? placeholder : undefined}
                value={value}
                returnKeyType={'next'}
                secureTextEntry={secureTextEntry}
                onChangeText={this.onChangeText.bind(this, onChangeValue)}
                leftIcon={
                    iconName && !isRight ?
                        <Icon
                            name={iconName}
                            type={iconType}
                            size={iconSize ? iconSize : size.text_size_medium}
                            color={iconColor ? iconColor : color.white}
                        /> : undefined
                }
                rightIcon={
                    iconName && isRight ?
                        <Icon
                            containerStyle={styles.icon}
                            name={iconName}
                            type={iconType}
                            size={iconSize ? iconSize : size.text_size_medium}
                            color={iconColor ? iconColor : color.white}
                        /> : showPassword ?
                        <Icon
                            containerStyle={styles.icon}
                            name={secureTextEntry ? 'eye-off' : 'eye'}
                            type={'material-community'}
                            size={size.text_size_medium}
                            color={iconColor}
                            underlayColor={color.transparent}
                            onPress={() => this.setState({secureTextEntry: !secureTextEntry})}
                        /> : undefined
                }
                {...this.props}/>
        )
    }

}

const styles = StyleSheet.create({
    container: {
        width: '100%',
        marginTop: size.size_16,
    },
    inputContainer: {
        marginHorizontal: size.size_16
    },
    input: {
        flex: 1,
        fontSize: size.text_size_small,
        fontFamily: font.regular,
    },
    underline: {
        borderBottomWidth: size.size_1,
    },
    border: {
        borderWidth: size.size_1,
    },
    multiline: {
        height: size.size_200,
        textAlignVertical: 'top'
    },
    label: {
        fontSize: size.text_size_v_small,
        fontFamily: font.regular,
        fontWeight: 'normal'
    },
    error: {
        fontSize: size.text_size_v_small,
        fontFamily: font.regular,
        color: color.error
    },
    icon: {
        marginRight: size.size_12
    }
});

export default InputView;