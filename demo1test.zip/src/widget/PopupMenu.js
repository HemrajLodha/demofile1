import React from "react";
import {Menu, MenuOption, MenuOptions, MenuTrigger, renderers} from "react-native-popup-menu";
import PropTypes from "prop-types";
import {ScrollView, StyleSheet, Text, View} from "react-native";
import {Icon} from "react-native-elements";
import color from "../../assets/values/color";
import size from "../../assets/values/dimens";
import font from "../../assets/values/font";
import Strings from "../../assets/strings/strings";
import ProgressView from "./ProgressView";

const {SlideInMenu, ContextMenu, Popover} = renderers;

class PopupMenu extends React.PureComponent {
    static propTypes = {
        options: PropTypes.array.isRequired,
        onSelect: PropTypes.func.isRequired,
    };

    constructor(props) {
        super(props);
        this.state = {
            options: []
        };
    }


    static getDerivedStateFromProps(nextProps, prevState) {
        let {placeHolder, options} = nextProps;
        let newOptions = !placeHolder ? options : [placeHolder, ...options];
        let nextState = (prevState.options == newOptions) ? null : {options: newOptions};
        return nextState;
    }

    render() {
        let {label, disabled, selected, selectedKey, selectedTitle, container, wrapper, error, underline, loading = false} = this.props;
        let {options} = this.state;
        return (
            <View style={[styles.container, container]}>
                <Menu
                    style={[styles.wrapper, wrapper, underline ? styles.underline : styles.border]}
                    renderer={ContextMenu}
                    rendererProps={{preferredPlacement: 'bottom'}}
                    onSelect={value => this.doSelect(value, selectedKey)}>
                    {
                        label &&
                        <Text style={styles.labelView}>{label}</Text>
                    }
                    <MenuTrigger customStyles={triggerStyles} disabled={disabled}>
                        <Text style={styles.text}>
                            {
                                this.getSelected(selected || "-1", selectedKey, selectedTitle)
                            }
                        </Text>
                        {
                            loading ? <ProgressView style={styles.loading}
                                                    size="small"
                                                    color={color.white}/>
                                : <Icon
                                    size={size.text_size_v_medium}
                                    name='angle-down'
                                    type={'font-awesome'}
                                    color={color.white}
                                />
                        }

                    </MenuTrigger>
                    <MenuOptions customStyles={optionsStyles}>
                        <ScrollView>
                            {
                                options.map((option, index) => {
                                    return <MenuOption key={index} text={option[selectedTitle]} value={option}/>
                                })
                            }
                        </ScrollView>
                    </MenuOptions>
                </Menu>
                {
                    error &&
                    <Text style={styles.errorView}>{error}</Text>
                }
            </View>
        );
    }

    doSelect = (value, key) => {
        let id = value[key];
        if (id == "-1")
            this.props.onSelect(undefined);
        else
            this.props.onSelect(value);
    };

    getSelected = (id, key, titleKey) => {
        let title = null;
        this.state.options.some(item => {
            if (item[key] === id) {
                title = item[titleKey];
                return true;
            }
            return false;
        });
        return title
    };

}

const styles = StyleSheet.create({
    container: {},
    wrapper: {
        margin: size.size_4
    },
    underline: {
        borderBottomColor: color.white,
        borderBottomWidth: size.size_1,
    },
    border: {
        borderColor: color.white,
        borderWidth: size.size_1,
    },
    errorView: {
        fontSize: size.text_size_v_small,
        fontFamily: font.regular,
        color: color.error,
        backgroundColor: color.transparent,
        marginHorizontal: size.size_16
    },
    labelView: {
        color: color.colorPrimary,
        fontFamily: font.bold,
        fontSize: size.text_size_v_small,
        paddingHorizontal: size.size_12,
        paddingTop: size.size_8
    },
    text: {
        fontSize: size.text_size_small,
        fontFamily: font.app,
        color: color.textColor,
        paddingHorizontal: size.size_2
    },
    loading: {
        flex: 0,
    }
});

const triggerStyles = {
    triggerOuterWrapper: {},
    triggerWrapper: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: size.size_12
    },
    triggerTouchable: {
        underlayColor: color.transparent,
        activeOpacity: 70,
    },
};

const optionsStyles = {
    optionsContainer: {
        width: "100%",
        backgroundColor: color.white,
        borderColor: color.gray_400,
        borderWidth: size.size_1,
        borderTopWidth: 0
    },
    optionsWrapper: {
        backgroundColor: color.white,
    },
    optionWrapper: {
        backgroundColor: color.white,
        padding: size.size_10,
        borderBottomColor: color.gray_400,
        borderBottomWidth: size.size_0_5,
    },
    optionTouchable: {
        underlayColor: color.transparent,
        activeOpacity: 70,
    },
    optionText: {
        textAlign: 'left',
        color: color.gray_700,
        fontFamily: font.bold,
        fontSize: size.text_size_v_small
    },
};

export default PopupMenu;