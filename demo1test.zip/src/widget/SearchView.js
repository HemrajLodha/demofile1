import React from "react";
import InputView from "./InputView";
import size from "../../assets/values/dimens";

class SearchView extends React.Component {

    render() {
        return (
            <InputView
                iconName={'search'}
                iconType={'font-awesome'}
                iconSize={size.text_size_small}
                underline={false}
                isLabel={false}
                {...this.props}/>
        );
    }

}

export default SearchView;