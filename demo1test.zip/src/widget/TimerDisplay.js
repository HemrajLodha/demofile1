import React from "react";
import PropTypes from "prop-types";
import Moment from "moment";
import {Text, TouchableOpacity, StyleSheet, Alert} from "react-native";
import Strings from "../../assets/strings/strings";
import font from "../../assets/values/font";
import size from "../../assets/values/dimens";
import color from "../../assets/values/color";
import ProgressView from "./ProgressView";

class TimerDisplay extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            start: Date.now(),
            duration: 0,
            timeLeft: 0,
            resend: false
        };
    }

    componentDidMount() {
        this.startTimer();
    }

    componentWillUnmount() {
        this.stopTimer();
    }

    static getDerivedStateFromProps(nextProps, prevState) {
        let {duration} = nextProps;
        let nextState = {duration, timeLeft: duration, resend: false, start: Date.now()};
        return nextState;
    }

    componentDidUpdate(prevProps, prevState) {
        if (this.props !== prevProps) {
            this.startTimer();
        }
    }

    render() {
        let {isSending, onPress, style} = this.props;
        let {timeLeft, resend} = this.state;
        return (
            <TouchableOpacity style={[styles.resendContainer, style]}
                              onPress={resend ? onPress : undefined}
                              disabled={isSending}
            >
                {
                    resend ? <Text style={styles.resend}>
                        {isSending ? Strings.resending_otp : Strings.resend_otp}
                    </Text> : <Text style={styles.resend}>
                        {Moment().startOf('day').add(timeLeft, 's').format('mm:ss')}
                    </Text>
                }
            </TouchableOpacity>
        );
    }

    startTimer() {
        this.stopTimer();
        let _this = this;
        this.timerCount = setInterval(function () {
            _this.timer();
        }, 1000);
    }

    stopTimer = () => {
        if (this.timerCount) {
            clearInterval(this.timerCount);
        }
    };

    timer() {
        let diff = this.state.duration - ((Date.now() - this.state.start) / 1000 | 0);
        this.setState({timeLeft: diff});
        if (diff <= 0) {
            this.setState({resend: true}, this.stopTimer);
        }
    }
}

const styles = StyleSheet.create({
    resendContainer: {
        alignSelf: 'flex-end',
    },
    resend: {
        fontSize: size.text_size_small,
        color: color.white,
        fontFamily: font.semibold,
        textDecorationLine: 'underline'
    },
});

TimerDisplay.propTypes = {
    duration: PropTypes.number.isRequired
};

export default TimerDisplay;



